var require = meteorInstall({"lib":{"collections":{"buildings.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections/buildings.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
                                                                                                                   //
var _meteorMongo = require('meteor/mongo');                                                                        //
                                                                                                                   //
var Buildings = new _meteorMongo.Mongo.Collection('buildings');                                                    // 3
                                                                                                                   //
Buildings.schema = new SimpleSchema({                                                                              // 5
  name: { type: String },                                                                                          // 6
  duration: { type: Number },                                                                                      // 7
  note: { type: String, optional: true },                                                                          // 8
  assigned: { type: Boolean, defaultValue: false },                                                                // 9
  active: { type: Boolean, defaultValue: true }                                                                    // 10
});                                                                                                                //
                                                                                                                   //
Buildings.attachSchema(Buildings.schema);                                                                          // 13
                                                                                                                   //
Buildings.helpers({                                                                                                // 16
  formattedDuration: function () {                                                                                 // 17
    return formatMinutes(this.duration);                                                                           // 18
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
exports['default'] = Buildings;                                                                                    //
module.exports = exports['default'];                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"cleaners.js":["meteor/mongo","./buildings.js","./schedules.js","./jobs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections/cleaners.js                                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
                                                                                                                   //
var _meteorMongo = require('meteor/mongo');                                                                        //
                                                                                                                   //
var _buildingsJs = require('./buildings.js');                                                                      //
                                                                                                                   //
var _buildingsJs2 = babelHelpers.interopRequireDefault(_buildingsJs);                                              //
                                                                                                                   //
var _schedulesJs = require('./schedules.js');                                                                      //
                                                                                                                   //
var _schedulesJs2 = babelHelpers.interopRequireDefault(_schedulesJs);                                              //
                                                                                                                   //
var _jobsJs = require('./jobs.js');                                                                                //
                                                                                                                   //
var _jobsJs2 = babelHelpers.interopRequireDefault(_jobsJs);                                                        //
                                                                                                                   //
var Cleaners = new _meteorMongo.Mongo.Collection('cleaners');                                                      // 6
                                                                                                                   //
Cleaners.schema = new SimpleSchema({                                                                               // 8
  name: { type: String },                                                                                          // 9
  salary: { type: Number, decimal: true, min: 0 },                                                                 // 10
  note: { type: String, optional: true },                                                                          // 11
  active: { type: Boolean, defaultValue: true }                                                                    // 12
});                                                                                                                //
                                                                                                                   //
Cleaners.attachSchema(Cleaners.schema);                                                                            // 15
                                                                                                                   //
Cleaners.helpers({                                                                                                 // 17
  scheduledBuildings: function (day) {                                                                             // 18
    var buildings = _schedulesJs2['default'].find({ cleaner_id: this._id, day: day }, { sort: { createdAt: 1 } }).fetch().map(function (item) {
      return _buildingsJs2['default'].findOne({ _id: item.building_id, active: true });                            // 20
    });                                                                                                            //
                                                                                                                   //
    return buildings;                                                                                              // 23
  },                                                                                                               //
                                                                                                                   //
  jobsForDate: function (date, done) {                                                                             // 26
    var selector = {                                                                                               // 27
      cleaner_id: this._id,                                                                                        // 28
      date: date                                                                                                   // 29
    };                                                                                                             //
                                                                                                                   //
    if (done != undefined) selector.done = done;                                                                   // 32
                                                                                                                   //
    return _jobsJs2['default'].find(selector).fetch();                                                             // 34
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
exports['default'] = Cleaners;                                                                                     //
module.exports = exports['default'];                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["meteor/mongo","./buildings.js","./cleaners.js","./schedules.js","./jobs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections/index.js                                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
                                                                                                                   //
var _meteorMongo = require('meteor/mongo');                                                                        //
                                                                                                                   //
var _buildingsJs = require('./buildings.js');                                                                      //
                                                                                                                   //
var _buildingsJs2 = babelHelpers.interopRequireDefault(_buildingsJs);                                              //
                                                                                                                   //
var _cleanersJs = require('./cleaners.js');                                                                        //
                                                                                                                   //
var _cleanersJs2 = babelHelpers.interopRequireDefault(_cleanersJs);                                                //
                                                                                                                   //
var _schedulesJs = require('./schedules.js');                                                                      //
                                                                                                                   //
var _schedulesJs2 = babelHelpers.interopRequireDefault(_schedulesJs);                                              //
                                                                                                                   //
var _jobsJs = require('./jobs.js');                                                                                //
                                                                                                                   //
var _jobsJs2 = babelHelpers.interopRequireDefault(_jobsJs);                                                        //
                                                                                                                   //
exports['default'] = {                                                                                             //
  Buildings: _buildingsJs2['default'],                                                                             // 9
  Cleaners: _cleanersJs2['default'],                                                                               // 10
  Schedules: _schedulesJs2['default'],                                                                             // 11
  Jobs: _jobsJs2['default']                                                                                        // 12
};                                                                                                                 //
module.exports = exports['default'];                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"jobs.js":["meteor/mongo","./buildings.js","./cleaners.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections/jobs.js                                                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
                                                                                                                   //
var _meteorMongo = require('meteor/mongo');                                                                        //
                                                                                                                   //
var _buildingsJs = require('./buildings.js');                                                                      //
                                                                                                                   //
var _buildingsJs2 = babelHelpers.interopRequireDefault(_buildingsJs);                                              //
                                                                                                                   //
var _cleanersJs = require('./cleaners.js');                                                                        //
                                                                                                                   //
var _cleanersJs2 = babelHelpers.interopRequireDefault(_cleanersJs);                                                //
                                                                                                                   //
var Jobs = new _meteorMongo.Mongo.Collection('jobs');                                                              // 5
                                                                                                                   //
Jobs.schema = new SimpleSchema({                                                                                   // 7
  date: { type: Date },                                                                                            // 8
  building_id: { type: String, optional: true },                                                                   // 9
  cleaner_id: { type: String },                                                                                    // 10
  salary: { type: Number, decimal: true, optional: true },                                                         // 11
  duration: { type: Number, decimal: true, optional: true },                                                       // 12
  price: { type: Number, decimal: true, optional: true },                                                          // 13
  paid: { type: Boolean, defaultValue: false },                                                                    // 14
  done: { type: Boolean, defaultValue: false }                                                                     // 15
});                                                                                                                //
                                                                                                                   //
Jobs.attachSchema(Jobs.schema);                                                                                    // 18
                                                                                                                   //
Jobs.helpers({                                                                                                     // 21
  building: function () {                                                                                          // 22
    return _buildingsJs2['default'].findOne(this.building_id);                                                     // 23
  },                                                                                                               //
                                                                                                                   //
  title: function () {                                                                                             // 26
    if (!this.building_id) return formatMinutes(this.duration);else return this.building().name;                   // 27
  },                                                                                                               //
                                                                                                                   //
  cleaner: function () {                                                                                           // 31
    return _cleanersJs2['default'].findOne(this.cleaner_id);                                                       // 32
  },                                                                                                               //
                                                                                                                   //
  isOvertime: function () {                                                                                        // 35
    return !this.building_id;                                                                                      // 36
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
exports['default'] = Jobs;                                                                                         //
module.exports = exports['default'];                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"schedules.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/collections/schedules.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
                                                                                                                   //
var _meteorMongo = require('meteor/mongo');                                                                        //
                                                                                                                   //
var Schedules = new _meteorMongo.Mongo.Collection('schedules');                                                    // 3
                                                                                                                   //
Schedules.schema = new SimpleSchema({                                                                              // 5
  day: { type: Number, min: 1, max: 7 },                                                                           // 6
  building_id: { type: String },                                                                                   // 7
  cleaner_id: { type: String },                                                                                    // 8
  createdAt: { type: Date }                                                                                        // 9
});                                                                                                                //
                                                                                                                   //
Schedules.attachSchema(Schedules.schema);                                                                          // 12
                                                                                                                   //
exports['default'] = Schedules;                                                                                    //
module.exports = exports['default'];                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"helpers.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/helpers.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
log = console.log.bind(console);                                                                                   // 1
                                                                                                                   //
formatMinutes = function (minutes) {                                                                               // 3
	return moment().hours(0).minutes(minutes).format('H:mm');                                                         // 4
};                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"weekdays.js":["enumify",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/weekdays.js                                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
                                                                                                                   //
var _enumify = require('enumify');                                                                                 //
                                                                                                                   //
var Weekdays = (function (_Enum) {                                                                                 //
  babelHelpers.inherits(Weekdays, _Enum);                                                                          //
                                                                                                                   //
  function Weekdays() {                                                                                            //
    babelHelpers.classCallCheck(this, Weekdays);                                                                   //
                                                                                                                   //
    _Enum.apply(this, arguments);                                                                                  //
  }                                                                                                                //
                                                                                                                   //
  Weekdays.prototype.date = (function () {                                                                         // 3
    function date() {                                                                                              // 4
      return moment({ hour: 0, minute: 0, second: 0 }).weekday(this.ordinal);                                      // 5
    }                                                                                                              //
                                                                                                                   //
    return date;                                                                                                   //
  })();                                                                                                            //
                                                                                                                   //
  return Weekdays;                                                                                                 //
})(_enumify.Enum);                                                                                                 //
                                                                                                                   //
Weekdays.initEnum({                                                                                                // 10
  'MONDAY': {                                                                                                      // 11
    value: 1,                                                                                                      // 12
    label: 'Pondelok'                                                                                              // 13
  },                                                                                                               //
  'TUESDAY': {                                                                                                     // 15
    value: 2,                                                                                                      // 16
    label: 'Utorok'                                                                                                // 17
  },                                                                                                               //
  'WEDNESDAY': {                                                                                                   // 19
    value: 3,                                                                                                      // 20
    label: 'Streda'                                                                                                // 21
  },                                                                                                               //
  'THURSDAY': {                                                                                                    // 23
    value: 4,                                                                                                      // 24
    label: 'Štvrtok'                                                                                               // 25
  },                                                                                                               //
  'FRIDAY': {                                                                                                      // 27
    value: 5,                                                                                                      // 28
    label: 'Piatok'                                                                                                // 29
  },                                                                                                               //
  'SATURDAY': {                                                                                                    // 31
    value: 6,                                                                                                      // 32
    label: 'Sobota'                                                                                                // 33
  },                                                                                                               //
  'SUNDAY': {                                                                                                      // 35
    value: 7,                                                                                                      // 36
    label: 'Nedeľa'                                                                                                // 37
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
exports['default'] = Weekdays;                                                                                     //
module.exports = exports['default'];                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"cron":{"index.js":["../scheduleEditor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cron/index.js                                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
//import SyncedCron from 'meteor/synced-cron';                                                                     //
                                                                                                                   //
var _scheduleEditor = require('../scheduleEditor');                                                                //
                                                                                                                   //
SyncedCron.add({                                                                                                   // 4
  name: 'Schedule jobs',                                                                                           // 5
  schedule: function (parser) {                                                                                    // 6
    // parser is a later.parse object                                                                              //
    return parser.text('on Monday at 0:01');                                                                       // 8
  },                                                                                                               //
  job: function () {                                                                                               // 10
    _scheduleEditor.createJobs();                                                                                  // 11
  }                                                                                                                //
});                                                                                                                //
                                                                                                                   //
Meteor.startup(function () {                                                                                       // 16
  SyncedCron.start();                                                                                              // 17
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods":{"buildings.js":["/lib/collections/index","meteor/meteor","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/methods/buildings.js                                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _meteorCheck = require('meteor/check');                                                                        //
                                                                                                                   //
_meteorMeteor.Meteor.methods({                                                                                     // 5
  'buildings.save': function (id, data) {                                                                          // 6
    _meteorCheck.check(id, _meteorCheck.Match.OneOf(String, null));                                                // 7
    _meteorCheck.check(data, {                                                                                     // 8
      name: String,                                                                                                // 9
      duration: Number,                                                                                            // 10
      note: String                                                                                                 // 11
    });                                                                                                            //
                                                                                                                   //
    // TODO: Do some user authorization                                                                            //
    if (id) {                                                                                                      // 15
      _libCollectionsIndex.Buildings.update(id, { $set: data });                                                   // 16
    } else {                                                                                                       //
      data.createdAt = new Date();                                                                                 // 18
      _libCollectionsIndex.Buildings.insert(data);                                                                 // 19
    }                                                                                                              //
  }                                                                                                                //
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"cleaners.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/methods/cleaners.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollections = require('/lib/collections');                                                                 //
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _meteorCheck = require('meteor/check');                                                                        //
                                                                                                                   //
_meteorMeteor.Meteor.methods({                                                                                     // 5
  'cleaners.save': function (id, data) {                                                                           // 6
    _meteorCheck.check(id, _meteorCheck.Match.OneOf(String, null));                                                // 7
    _meteorCheck.check(data, {                                                                                     // 8
      name: String,                                                                                                // 9
      salary: Number,                                                                                              // 10
      note: String                                                                                                 // 11
    });                                                                                                            //
                                                                                                                   //
    // TODO: Do some user authorization                                                                            //
                                                                                                                   //
    if (id) {                                                                                                      // 16
      _libCollections.Cleaners.update(id, { $set: data });                                                         // 17
    } else {                                                                                                       //
      data.createdAt = new Date();                                                                                 // 19
      _libCollections.Cleaners.insert(data);                                                                       // 20
    }                                                                                                              //
  }                                                                                                                //
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"jobs.js":["/lib/collections/index","meteor/meteor","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/methods/jobs.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _meteorCheck = require('meteor/check');                                                                        //
                                                                                                                   //
_meteorMeteor.Meteor.methods({                                                                                     // 5
  'jobs.markAllAsPaid': function (cleanerId, month) {                                                              // 6
    _meteorCheck.check(cleanerId, String);                                                                         // 7
    _meteorCheck.check(month, String);                                                                             // 8
                                                                                                                   //
    var monthStart = moment(month, 'YYYYMM').startOf('month').toDate();                                            // 10
    var monthEnd = moment(month, 'YYYYMM').endOf('month').toDate();                                                // 11
                                                                                                                   //
    _libCollectionsIndex.Jobs.update({ cleaner_id: cleanerId, date: { $gte: monthStart, $lte: monthEnd } }, { $set: { paid: true } }, { multi: true });
  }                                                                                                                //
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"all.js":["/lib/collections/index","meteor/meteor","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/publications/all.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _meteorCheck = require('meteor/check');                                                                        //
                                                                                                                   //
_meteorMeteor.Meteor.publish('core.init', function () {                                                            // 5
  return [_libCollectionsIndex.Buildings.find(), _libCollectionsIndex.Cleaners.find(), _libCollectionsIndex.Schedules.find()];
});                                                                                                                //
                                                                                                                   //
_meteorMeteor.Meteor.publish('jobs.todo', function () {                                                            // 14
  var today = moment({ hour: 0, minute: 0, second: 0 });                                                           // 15
  return _libCollectionsIndex.Jobs.find({ $or: [{ done: false }, { date: today.toDate() }] });                     // 16
});                                                                                                                //
                                                                                                                   //
_meteorMeteor.Meteor.publish('jobs.monthlyReport', function (month, cleanerId) {                                   // 19
  var monthStart = moment(month, 'YYYYMM').startOf('month').toDate();                                              // 20
  var monthEnd = moment(month, 'YYYYMM').endOf('month').toDate();                                                  // 21
                                                                                                                   //
  return _libCollectionsIndex.Jobs.find({ cleaner_id: cleanerId, date: { $gte: monthStart, $lte: monthEnd }, done: true });
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"seed":{"startup.js":["meteor/meteor","/lib/collections/index","dr-seeder","../scheduleEditor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/seed/startup.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
var _drSeeder = require('dr-seeder');                                                                              //
                                                                                                                   //
var _drSeeder2 = babelHelpers.interopRequireDefault(_drSeeder);                                                    //
                                                                                                                   //
var _scheduleEditor = require('../scheduleEditor');                                                                //
                                                                                                                   //
_meteorMeteor.Meteor.startup(function () {                                                                         // 6
                                                                                                                   //
  _drSeeder2['default'].seed('Buildings init', _libCollectionsIndex.Buildings, {                                   // 8
    data: [{ name: 'Letomostie 7', duration: 60, assigned: true }, { name: 'Letomostie 11', duration: 60, assigned: true }, { name: 'Letomostie 13', duration: 60, assigned: true }, { name: 'Letomostie 15', duration: 60, assigned: true }, { name: 'Novomestská 2', duration: 60, assigned: true }, { name: 'Novomestská 4', duration: 60, assigned: true }, { name: 'T.G.Masaryka 30', duration: 60, assigned: true }, { name: 'T.G.Masaryka 28', duration: 60, assigned: true }, { name: 'T.G.Masaryka 17', duration: 30, assigned: true }, { name: 'Podzámska 1', duration: 60, assigned: true }, { name: 'Podzámska 7', duration: 60, assigned: true }, { name: 'MAGNUM', duration: 150, assigned: true }, { name: 'T.G. Masaryka 14', duration: 60, assigned: true }, { name: 'T.G. Masaryka 16', duration: 60, assigned: true }, { name: 'T.G. Masaryka 18', duration: 60, assigned: true }, { name: 'SNP. 48', duration: 60, assigned: true }, { name: 'SNP. 50', duration: 60, assigned: true }, { name: 'SNP. 52', duration: 60, assigned: true }, { name: 'SNP. 54', duration: 60, assigned: true }, { name: 'Gymnastická hala', duration: 90, assigned: true }, { name: 'ABC klíma', duration: 60, assigned: true }, { name: 'G. Bethlena 57', duration: 60, assigned: true }, { name: 'Cyrilometódska 44', duration: 30, assigned: true }, { name: 'Cyrilometódska 46', duration: 30, assigned: true }, { name: 'Cyrilometódska 48', duration: 30, assigned: true }, { name: 'SNP 58', duration: 30, assigned: true }, { name: 'Šafáriková 26', duration: 30, assigned: true }, { name: 'Šafáriková 28', duration: 30, assigned: true }, { name: 'Šafáriková 22', duration: 60, assigned: true }, { name: 'Šafáriková 20', duration: 60, assigned: true }, { name: 'Šafáriková 2', duration: 30, assigned: true }, { name: 'Lastovičia 3', duration: 60, assigned: true }, { name: 'Lastovičia 1', duration: 60, assigned: true }, { name: 'Nábrežná 7', duration: 60, assigned: true }, { name: 'Nábrežná 9', duration: 60, assigned: true }, { name: 'Nábrežná 13', duration: 60, assigned: true }, { name: 'Andovská 21', duration: 60, assigned: true }, { name: 'Andovská 23', duration: 60, assigned: true }, { name: 'S.H. Vajanského 37', duration: 60, assigned: true }, { name: 'S.H. Vajanského 39', duration: 60, assigned: true }, { name: 'S.H. Vajanského 41', duration: 60, assigned: true }, { name: 'T. Vansovej 32', duration: 60, assigned: true }, { name: 'T. Vansovej 30', duration: 60, assigned: true }, { name: 'Komárňanska 59', duration: 150, assigned: true }, { name: 'Dom politických strán', duration: 60, assigned: true }, { name: 'Komárňanska 29', duration: 30, assigned: true }, { name: 'Komárňanska 27', duration: 30, assigned: true }, { name: 'Nábrežná 35', duration: 60, assigned: true }, { name: 'Nábrežná 37', duration: 60, assigned: true }, { name: 'Nábrežná 53', duration: 60, assigned: true }, { name: 'Nábrežná 55', duration: 60, assigned: true }, { name: 'S.H Vajanského 9', duration: 60, assigned: true }, { name: 'S.H Vajanského 17', duration: 60, assigned: true }, { name: 'Šoltésová 9', duration: 60, assigned: true }, { name: 'J.Krála 20', duration: 60, assigned: true }, { name: 'J.Krála 22', duration: 60, assigned: true }, { name: 'T. Vansovej 24', duration: 60, assigned: true }, { name: 'T. Vansovej 22', duration: 60, assigned: true }, { name: 'T. Vansovej 20', duration: 60, assigned: true }, { name: 'T. Vansovej 18', duration: 60, assigned: true }, { name: 'T. Vansovej 16', duration: 60, assigned: true }, { name: 'T. Vansovej 14', duration: 60, assigned: true }, { name: 'Gogoľova 1', duration: 30, assigned: true }, { name: 'Gogoľova 3', duration: 60, assigned: true }, { name: 'Gogoľova 5', duration: 60, assigned: true }, { name: 'Krasková 4', duration: 60, assigned: true }, { name: 'Holého 4', duration: 90, assigned: true }, { name: 'Hlboká 1', duration: 30, assigned: true }, { name: 'Gogoľová 2', duration: 60, assigned: true }, { name: 'Komárňanska 31', duration: 60, assigned: true }, { name: 'Ďorocká 3', duration: 60, assigned: true }, { name: 'Ďorocká 5', duration: 60, assigned: true }, { name: 'Ďorocká 7', duration: 60, assigned: true }, { name: 'T.G. Masaryka 32', duration: 60, assigned: true }, { name: 'T.G. Masaryka 34', duration: 60, assigned: true }, { name: 'T.G. Masaryka 36', duration: 60, assigned: true }, { name: 'Gymnastická hala', duration: 90, assigned: true }, { name: 'M.R. Stefánika 49', duration: 60, assigned: true }, { name: 'Nábrežná 99', duration: 90, assigned: true }, { name: 'Nábrežná 20', duration: 90, assigned: true }, { name: 'S.H. Vajanského 70', duration: 60, assigned: true }, { name: 'S.H. Vajanského 72', duration: 60, assigned: true }, { name: 'Várdayho 13', duration: 30, assigned: true }, { name: 'Bitúnková 1', duration: 60, assigned: true }, { name: 'Bitúnková 3', duration: 60, assigned: true }, { name: 'Bitúnková 5', duration: 60, assigned: true }, { name: 'Bitúnková 7', duration: 60, assigned: true }, { name: 'Bitúnková 9', duration: 60, assigned: true }, { name: 'Bitúnková 11', duration: 60, assigned: true }, { name: 'L. Štúra 16B', duration: 60, assigned: true }, { name: 'MAGNUM', duration: 90, assigned: true }, { name: 'Bajč 197A', duration: 60, assigned: true }, { name: 'Bajč 197B', duration: 60, assigned: true }, { name: 'Námestie republiky 2', duration: 90, assigned: true }, { name: 'Bitúnková 1', duration: 60, assigned: true }, { name: 'Bitúnková 3', duration: 60, assigned: true }, { name: 'Bitúnková 5', duration: 60, assigned: true }, { name: 'Nábrežná 51', duration: 60, assigned: true }, { name: 'Gymnastická hala', duration: 90, assigned: true }, { name: 'Gogoľová 9', duration: 30, assigned: true }, { name: 'Gogoľová 11', duration: 60, assigned: true }, { name: 'Gogoľová 17', duration: 60, assigned: true }, { name: 'Cyrilometódska 28', duration: 60, assigned: true }, { name: 'Cyrilometódska 30', duration: 60, assigned: true }, { name: 'Cyrilometódska 32', duration: 60, assigned: true }, { name: 'SNP 42', duration: 60, assigned: true }, { name: 'Andovská 15', duration: 30, assigned: true }, { name: 'Andovská 21', duration: 60, assigned: true }, { name: 'Andovská 23', duration: 60, assigned: true }, { name: 'Andovská 25A', duration: 30, assigned: true }, { name: 'Andovská 25B', duration: 60, assigned: true }, { name: 'Andovská 25E', duration: 30, assigned: true }, { name: 'Jazdecká 15', duration: 60, assigned: true }, { name: 'Jazdecká 17', duration: 60, assigned: true }, { name: 'Jazdecká 14', duration: 60, assigned: true }, { name: 'Jazdecká 18', duration: 60, assigned: true }, { name: 'Komenského 1', duration: 30, assigned: true }, { name: 'Komenského 2', duration: 30, assigned: true }, { name: 'Bezručová 8', duration: 30, assigned: true }, { name: 'Bezručová 10', duration: 30, assigned: true }, { name: 'Žerotínová bašta 13', duration: 60, assigned: true }, { name: 'Žerotínová bašta 15', duration: 60, assigned: true }]
  });                                                                                                              //
                                                                                                                   //
  _drSeeder2['default'].seed('Cleaners init', _libCollectionsIndex.Cleaners, {                                     // 135
    data: [{ name: 'Lenka B.', salary: 2.7 }, { name: 'Janka D.', salary: 2.5 }, { name: 'Katka K.', salary: 2.7 }, { name: 'Gabika K.', salary: 2.5 }, { name: 'Nika Č.', salary: 2.5 }, { name: 'Gabika C.', salary: 2.5 }]
  });                                                                                                              //
                                                                                                                   //
  var allBuildings = _libCollectionsIndex.Buildings.find().fetch();                                                // 146
  allBuildings = _.indexBy(allBuildings, 'name');                                                                  // 147
                                                                                                                   //
  var allCleaners = _libCollectionsIndex.Cleaners.find().fetch();                                                  // 149
  allCleaners = _.indexBy(allCleaners, 'name');                                                                    // 150
                                                                                                                   //
  var scheduleData = [{ day: 1, building: 'Letomostie 7', cleaner: 'Lenka B.' }, { day: 1, building: 'Letomostie 11', cleaner: 'Lenka B.' }, { day: 1, building: 'Letomostie 13', cleaner: 'Lenka B.' }, { day: 1, building: 'Letomostie 15', cleaner: 'Lenka B.' }, { day: 1, building: 'Novomestská 2', cleaner: 'Janka D.' }, { day: 1, building: 'Novomestská 4', cleaner: 'Janka D.' }, { day: 1, building: 'T.G.Masaryka 30', cleaner: 'Janka D.' }, { day: 1, building: 'T.G.Masaryka 28', cleaner: 'Janka D.' }, { day: 1, building: 'T.G.Masaryka 17', cleaner: 'Janka D.' }, { day: 1, building: 'Podzámska 1', cleaner: 'Katka K.' }, { day: 1, building: 'Podzámska 7', cleaner: 'Katka K.' }, { day: 1, building: 'MAGNUM', cleaner: 'Katka K.' }, { day: 1, building: 'T.G. Masaryka 14', cleaner: 'Katka K.' }, { day: 1, building: 'T.G. Masaryka 16', cleaner: 'Katka K.' }, { day: 1, building: 'T.G. Masaryka 18', cleaner: 'Katka K.' }, { day: 1, building: 'SNP. 48', cleaner: 'Gabika K.' }, { day: 1, building: 'SNP. 50', cleaner: 'Gabika K.' }, { day: 1, building: 'SNP. 52', cleaner: 'Gabika K.' }, { day: 1, building: 'SNP. 54', cleaner: 'Gabika K.' }, { day: 1, building: 'Gymnastická hala', cleaner: 'Nika Č.' }, { day: 1, building: 'ABC klíma', cleaner: 'Nika Č.' }, { day: 1, building: 'G. Bethlena 57', cleaner: 'Nika Č.' }, { day: 1, building: 'Cyrilometódska 44', cleaner: 'Gabika C.' }, { day: 1, building: 'Cyrilometódska 46', cleaner: 'Gabika C.' }, { day: 1, building: 'Cyrilometódska 48', cleaner: 'Gabika C.' }, { day: 1, building: 'SNP 58', cleaner: 'Gabika C.' }, { day: 2, building: 'Šafáriková 26', cleaner: 'Lenka B.' }, { day: 2, building: 'Šafáriková 28', cleaner: 'Lenka B.' }, { day: 2, building: 'Šafáriková 22', cleaner: 'Lenka B.' }, { day: 2, building: 'Šafáriková 20', cleaner: 'Lenka B.' }, { day: 2, building: 'Šafáriková 2', cleaner: 'Lenka B.' }, { day: 2, building: 'Lastovičia 3', cleaner: 'Lenka B.' }, { day: 2, building: 'Lastovičia 1', cleaner: 'Lenka B.' }, { day: 2, building: 'Nábrežná 7', cleaner: 'Janka D.' }, { day: 2, building: 'Nábrežná 9', cleaner: 'Janka D.' }, { day: 2, building: 'Nábrežná 13', cleaner: 'Janka D.' }, { day: 2, building: 'Andovská 21', cleaner: 'Janka D.' }, { day: 2, building: 'Andovská 23', cleaner: 'Janka D.' }, { day: 2, building: 'S.H. Vajanského 37', cleaner: 'Katka K.' }, { day: 2, building: 'S.H. Vajanského 39', cleaner: 'Katka K.' }, { day: 2, building: 'S.H. Vajanského 41', cleaner: 'Katka K.' }, { day: 2, building: 'T. Vansovej 32', cleaner: 'Katka K.' }, { day: 2, building: 'T. Vansovej 30', cleaner: 'Katka K.' }, { day: 2, building: 'Komárňanska 59', cleaner: 'Gabika K.' }, { day: 2, building: 'Dom politických strán', cleaner: 'Gabika K.' }, { day: 2, building: 'Komárňanska 29', cleaner: 'Gabika K.' }, { day: 2, building: 'Komárňanska 27', cleaner: 'Gabika K.' }, { day: 2, building: 'Nábrežná 35', cleaner: 'Gabika C.' }, { day: 2, building: 'Nábrežná 37', cleaner: 'Gabika C.' }, { day: 2, building: 'Nábrežná 53', cleaner: 'Gabika C.' }, { day: 2, building: 'Nábrežná 55', cleaner: 'Gabika C.' }, { day: 3, building: 'S.H Vajanského 9', cleaner: 'Lenka B.' }, { day: 3, building: 'S.H Vajanského 17', cleaner: 'Lenka B.' }, { day: 3, building: 'Šoltésová 9', cleaner: 'Lenka B.' }, { day: 3, building: 'J.Krála 20', cleaner: 'Lenka B.' }, { day: 3, building: 'J.Krála 22', cleaner: 'Lenka B.' }, { day: 3, building: 'T. Vansovej 24', cleaner: 'Janka D.' }, { day: 3, building: 'T. Vansovej 22', cleaner: 'Janka D.' }, { day: 3, building: 'T. Vansovej 20', cleaner: 'Janka D.' }, { day: 3, building: 'T. Vansovej 18', cleaner: 'Janka D.' }, { day: 3, building: 'T. Vansovej 16', cleaner: 'Janka D.' }, { day: 3, building: 'T. Vansovej 14', cleaner: 'Janka D.' }, { day: 3, building: 'Gogoľova 1', cleaner: 'Katka K.' }, { day: 3, building: 'Gogoľova 3', cleaner: 'Katka K.' }, { day: 3, building: 'Gogoľova 5', cleaner: 'Katka K.' }, { day: 3, building: 'Krasková 4', cleaner: 'Katka K.' }, { day: 3, building: 'Holého 4', cleaner: 'Katka K.' }, { day: 3, building: 'Hlboká 1', cleaner: 'Katka K.' }, { day: 3, building: 'Gogoľová 2', cleaner: 'Gabika K.' }, { day: 3, building: 'Komárňanska 31', cleaner: 'Gabika K.' }, { day: 3, building: 'Ďorocká 3', cleaner: 'Gabika K.' }, { day: 3, building: 'Ďorocká 5', cleaner: 'Gabika K.' }, { day: 3, building: 'Ďorocká 7', cleaner: 'Gabika K.' }, { day: 3, building: 'T.G. Masaryka 32', cleaner: 'Nika Č.' }, { day: 3, building: 'T.G. Masaryka 34', cleaner: 'Nika Č.' }, { day: 3, building: 'T.G. Masaryka 36', cleaner: 'Nika Č.' }, { day: 3, building: 'Gymnastická hala', cleaner: 'Gabika C.' }, { day: 3, building: 'M.R. Stefánika 49', cleaner: 'Gabika C.' }, { day: 4, building: 'Nábrežná 99', cleaner: 'Lenka B.' }, { day: 4, building: 'Nábrežná 20', cleaner: 'Lenka B.' }, { day: 4, building: 'S.H. Vajanského 70', cleaner: 'Lenka B.' }, { day: 4, building: 'S.H. Vajanského 72', cleaner: 'Lenka B.' }, { day: 4, building: 'Várdayho 13', cleaner: 'Lenka B.' }, { day: 4, building: 'Bitúnková 1', cleaner: 'Janka D.' }, { day: 4, building: 'Bitúnková 3', cleaner: 'Janka D.' }, { day: 4, building: 'Bitúnková 5', cleaner: 'Janka D.' }, { day: 4, building: 'Bitúnková 7', cleaner: 'Janka D.' }, { day: 4, building: 'Bitúnková 9', cleaner: 'Janka D.' }, { day: 4, building: 'Bitúnková 11', cleaner: 'Janka D.' }, { day: 4, building: 'L. Štúra 16B', cleaner: 'Katka K.' }, { day: 4, building: 'MAGNUM', cleaner: 'Katka K.' }, { day: 4, building: 'Bajč 197A', cleaner: 'Katka K.' }, { day: 4, building: 'Bajč 197B', cleaner: 'Katka K.' }, { day: 4, building: 'Námestie republiky 2', cleaner: 'Katka K.' }, { day: 4, building: 'Bitúnková 1', cleaner: 'Gabika K.' }, { day: 4, building: 'Bitúnková 3', cleaner: 'Gabika K.' }, { day: 4, building: 'Bitúnková 5', cleaner: 'Gabika K.' }, { day: 4, building: 'Nábrežná 51', cleaner: 'Gabika K.' }, { day: 4, building: 'Gymnastická hala', cleaner: 'Gabika C.' }, { day: 4, building: 'Gogoľová 9', cleaner: 'Gabika C.' }, { day: 4, building: 'Gogoľová 11', cleaner: 'Gabika C.' }, { day: 4, building: 'Gogoľová 17', cleaner: 'Gabika C.' }, { day: 5, building: 'Cyrilometódska 28', cleaner: 'Lenka B.' }, { day: 5, building: 'Cyrilometódska 30', cleaner: 'Lenka B.' }, { day: 5, building: 'Cyrilometódska 32', cleaner: 'Lenka B.' }, { day: 5, building: 'SNP 42', cleaner: 'Lenka B.' }, { day: 5, building: 'Andovská 15', cleaner: 'Janka D.' }, { day: 5, building: 'Andovská 21', cleaner: 'Janka D.' }, { day: 5, building: 'Andovská 23', cleaner: 'Janka D.' }, { day: 5, building: 'Andovská 25A', cleaner: 'Janka D.' }, { day: 5, building: 'Andovská 25B', cleaner: 'Janka D.' }, { day: 5, building: 'Andovská 25E', cleaner: 'Janka D.' }, { day: 5, building: 'Jazdecká 15', cleaner: 'Katka K.' }, { day: 5, building: 'Jazdecká 17', cleaner: 'Katka K.' }, { day: 5, building: 'Jazdecká 14', cleaner: 'Katka K.' }, { day: 5, building: 'Jazdecká 18', cleaner: 'Katka K.' }, { day: 5, building: 'Komenského 1', cleaner: 'Katka K.' }, { day: 5, building: 'Komenského 2', cleaner: 'Katka K.' }, { day: 5, building: 'Bezručová 8', cleaner: 'Katka K.' }, { day: 5, building: 'Bezručová 10', cleaner: 'Katka K.' }, { day: 5, building: 'Žerotínová bašta 13', cleaner: 'Gabika K.' }, { day: 5, building: 'Žerotínová bašta 15', cleaner: 'Gabika K.' }];
                                                                                                                   //
  // var scheduleData1 = [];                                                                                       //
  // _.each(scheduleData, function(item, index) {                                                                  //
                                                                                                                   //
  //     if (!allBuildings[item.building]) log('Missing building:', item.building)                                 //
  //     if (!allCleaners[item.cleaner]) log('Missing cleaner:-' + item.cleaner + '-')                             //
  //     scheduleData1.push({                                                                                      //
  //           building_id: allBuildings[item.building]._id,                                                       //
  //           cleaner_id: allCleaners[item.cleaner]._id,                                                          //
  //           createdAt: new Date(),                                                                              //
  //           day: item.day                                                                                       //
  //     })                                                                                                        //
  // });                                                                                                           //
                                                                                                                   //
  // Seeder.seed('Schedules init', Schedules, {                                                                    //
  //   data: scheduleData1                                                                                         //
  // });                                                                                                           //
                                                                                                                   //
  _scheduleEditor.createJobs();                                                                                    // 294
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"migrations.js":["/lib/collections/index",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/migrations.js                                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
Meteor.startup(function () {                                                                                       // 4
  Migrations.migrateTo('latest');                                                                                  // 5
});                                                                                                                //
                                                                                                                   //
Migrations.add({                                                                                                   // 9
  version: 1,                                                                                                      // 10
  name: 'Add `active` field to Buildings and Cleaners',                                                            // 11
  up: function () {                                                                                                // 12
    _libCollectionsIndex.Buildings.update({}, { $set: { active: true } }, { multi: true });                        // 13
    _libCollectionsIndex.Cleaners.update({}, { $set: { active: true } }, { multi: true });                         // 14
  }                                                                                                                //
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"schedule.js":["/lib/collections/index","meteor/meteor","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/schedule.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _meteorCheck = require('meteor/check');                                                                        //
                                                                                                                   //
_meteorMeteor.Meteor.methods({                                                                                     // 5
  'schedule.markAsDone': function (jobId) {                                                                        // 6
    _meteorCheck.check(jobId, String);                                                                             // 7
                                                                                                                   //
    var today = moment({ hour: 0, minute: 0, second: 0 });                                                         // 9
    var job = _libCollectionsIndex.Jobs.findOne(jobId);                                                            // 10
    var cleaner = _libCollectionsIndex.Cleaners.findOne(job.cleaner_id);                                           // 11
    var building = _libCollectionsIndex.Buildings.findOne(job.building_id);                                        // 12
                                                                                                                   //
    var update = {                                                                                                 // 14
      date: today.toDate(),                                                                                        // 15
      done: true,                                                                                                  // 16
      salary: cleaner.salary,                                                                                      // 17
      duration: building.duration                                                                                  // 18
    };                                                                                                             //
    log(update);                                                                                                   // 20
    _libCollectionsIndex.Jobs.update(jobId, { $set: update });                                                     // 21
  },                                                                                                               //
                                                                                                                   //
  'schedule.reassign': function (jobId, cleanerId) {                                                               // 24
    _meteorCheck.check(jobId, String);                                                                             // 25
    _meteorCheck.check(cleanerId, String);                                                                         // 26
                                                                                                                   //
    var today = moment({ hour: 0, minute: 0, second: 0 });                                                         // 28
    var job = _libCollectionsIndex.Jobs.findOne(jobId);                                                            // 29
                                                                                                                   //
    var cleaner = _libCollectionsIndex.Cleaners.findOne(cleanerId);                                                // 31
    var building = _libCollectionsIndex.Buildings.findOne(job.building_id);                                        // 32
                                                                                                                   //
    _libCollectionsIndex.Jobs.update(jobId, { $set: {                                                              // 34
        cleaner_id: cleanerId,                                                                                     // 35
        date: today.toDate(),                                                                                      // 36
        salary: cleaner.salary,                                                                                    // 37
        duration: building.duration,                                                                               // 38
        done: true                                                                                                 // 39
      } });                                                                                                        //
  },                                                                                                               //
                                                                                                                   //
  'schedule.cancel': function (jobId) {                                                                            // 43
    _meteorCheck.check(jobId, String);                                                                             // 44
    _libCollectionsIndex.Jobs.update(jobId, { $set: { done: false } });                                            // 45
  },                                                                                                               //
                                                                                                                   //
  'schedule.skip': function (jobId) {                                                                              // 48
    _meteorCheck.check(jobId, String);                                                                             // 49
    _libCollectionsIndex.Jobs.remove(jobId);                                                                       // 50
  },                                                                                                               //
                                                                                                                   //
  'schedule.addOvertime': function (cleanerId, date, overtime) {                                                   // 53
    _meteorCheck.check(cleanerId, String);                                                                         // 54
    _meteorCheck.check(date, Date);                                                                                // 55
    _meteorCheck.check(overtime, Number);                                                                          // 56
                                                                                                                   //
    var overtimeJob = _libCollectionsIndex.Jobs.findOne({ cleaner_id: cleanerId, date: date, building_id: null });
    var cleaner = _libCollectionsIndex.Cleaners.findOne(cleanerId);                                                // 59
                                                                                                                   //
    if (overtimeJob) {                                                                                             // 61
      _libCollectionsIndex.Jobs.update(overtimeJob._id, { $inc: { duration: overtime } });                         // 62
    } else {                                                                                                       //
      _libCollectionsIndex.Jobs.insert({                                                                           // 64
        cleaner_id: cleanerId,                                                                                     // 65
        building_id: null,                                                                                         // 66
        date: date,                                                                                                // 67
        done: true,                                                                                                // 68
        salary: cleaner.salary,                                                                                    // 69
        duration: overtime                                                                                         // 70
      });                                                                                                          //
    }                                                                                                              //
  },                                                                                                               //
                                                                                                                   //
  'schedule.cancelOvertime': function (cleanerId, date) {                                                          // 75
    _meteorCheck.check(cleanerId, String);                                                                         // 76
    _meteorCheck.check(date, Date);                                                                                // 77
                                                                                                                   //
    _libCollectionsIndex.Jobs.remove({ cleaner_id: cleanerId, date: date, building_id: null });                    // 79
  }                                                                                                                //
});                                                                                                                //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"scheduleEditor.js":["/lib/collections/index","meteor/meteor","meteor/check","/lib/weekdays.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/scheduleEditor.js                                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.__esModule = true;                                                                                         //
exports.createJobs = createJobs;                                                                                   //
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
var _meteorMeteor = require('meteor/meteor');                                                                      //
                                                                                                                   //
var _meteorCheck = require('meteor/check');                                                                        //
                                                                                                                   //
var _libWeekdaysJs = require('/lib/weekdays.js');                                                                  //
                                                                                                                   //
var _libWeekdaysJs2 = babelHelpers.interopRequireDefault(_libWeekdaysJs);                                          //
                                                                                                                   //
_meteorMeteor.Meteor.methods({                                                                                     // 8
  'scheduleEditor.assign': function (parameters) {                                                                 // 9
    _meteorCheck.check(parameters, {                                                                               // 10
      buildingId: String,                                                                                          // 11
      cleanerId: String,                                                                                           // 12
      day: Number                                                                                                  // 13
    });                                                                                                            //
                                                                                                                   //
    // TODO: Do some user authorization                                                                            //
                                                                                                                   //
    // un-assign building                                                                                          //
    _libCollectionsIndex.Schedules.remove({ building_id: parameters.buildingId });                                 // 19
                                                                                                                   //
    var createdAt = new Date();                                                                                    // 22
    var data = { building_id: parameters.buildingId, cleaner_id: parameters.cleanerId, day: parameters.day, createdAt: createdAt };
                                                                                                                   //
    _libCollectionsIndex.Schedules.insert(data);                                                                   // 25
                                                                                                                   //
    _libCollectionsIndex.Buildings.update(parameters.buildingId, { $set: { assigned: true } });                    // 27
  }                                                                                                                //
                                                                                                                   //
});                                                                                                                //
                                                                                                                   //
// create jobs                                                                                                     //
                                                                                                                   //
function createJobs() {                                                                                            // 37
                                                                                                                   //
  var monday = moment({ hour: 0, minute: 0, second: 0 }).weekday(0);                                               // 39
  var sunday = moment({ hour: 0, minute: 0, second: 0 }).weekday(6);                                               // 40
                                                                                                                   //
  var selector = {                                                                                                 // 42
    $and: [{ date: { $gte: monday.toDate() } }, { date: { $lte: sunday.toDate() } }]                               // 43
  };                                                                                                               //
                                                                                                                   //
  if (_libCollectionsIndex.Jobs.find(selector).count()) {                                                          // 49
    log('This week already scheduled!');                                                                           // 50
    return null;                                                                                                   // 51
  }                                                                                                                //
                                                                                                                   //
  var newJobs = [];                                                                                                // 54
  _libWeekdaysJs2['default'].enumValues.map(function (day) {                                                       // 55
    var date = day.date();                                                                                         // 56
    var schedules = _libCollectionsIndex.Schedules.find({ day: day.value }).fetch();                               // 57
                                                                                                                   //
    schedules.map(function (schedule) {                                                                            // 59
      var data = {                                                                                                 // 60
        building_id: schedule.building_id,                                                                         // 61
        cleaner_id: schedule.cleaner_id,                                                                           // 62
        date: date.toDate()                                                                                        // 63
      };                                                                                                           //
                                                                                                                   //
      newJobs.push(_libCollectionsIndex.Jobs.insert(data));                                                        // 66
    });                                                                                                            //
  });                                                                                                              //
                                                                                                                   //
  log(newJobs.length + ' new Jobs created');                                                                       // 71
}                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"security.js":["/lib/collections/index",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/security.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _libCollectionsIndex = require('/lib/collections/index');                                                      //
                                                                                                                   //
_libCollectionsIndex.Cleaners.permit(['update']).onlyProps(['active']).apply();                                    // 4
_libCollectionsIndex.Buildings.permit(['update']).onlyProps(['active']).apply();                                   // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"node_modules":{"enumify":{"package.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/enumify/package.json                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
exports.name = "enumify";                                                                                          // 1
exports.main = "./lib/enumify.js";                                                                                 // 2
                                                                                                                   // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"enumify.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/enumify/lib/enumify.js                                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
'use strict';                                                                                                      // 1
                                                                                                                   // 2
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };
                                                                                                                   // 4
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
                                                                                                                   // 6
Object.defineProperty(exports, "__esModule", {                                                                     // 7
    value: true                                                                                                    // 8
});                                                                                                                // 9
exports.copyProperties = copyProperties;                                                                           // 10
                                                                                                                   // 11
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
                                                                                                                   // 13
var INITIALIZED = Symbol();                                                                                        // 14
                                                                                                                   // 15
/**                                                                                                                // 16
 * This is an abstract class that is not intended to be                                                            // 17
 * used directly. Extend it to turn your class into an enum                                                        // 18
 * (initialization is performed via `MyClass.initEnum()`).                                                         // 19
 */                                                                                                                // 20
                                                                                                                   // 21
var Enum = exports.Enum = function () {                                                                            // 22
    /**                                                                                                            // 23
     * `initEnum()` closes the class. Then calling this constructor                                                // 24
     * throws an exception.                                                                                        // 25
     *                                                                                                             // 26
     * If your subclass has a constructor then you can control                                                     // 27
     * what properties are added to `this` via the argument you                                                    // 28
     * pass to `super()`. No arguments are fine, too.                                                              // 29
     */                                                                                                            // 30
                                                                                                                   // 31
    function Enum() {                                                                                              // 32
        var instanceProperties = arguments.length <= 0 || arguments[0] === undefined ? undefined : arguments[0];   // 33
                                                                                                                   // 34
        _classCallCheck(this, Enum);                                                                               // 35
                                                                                                                   // 36
        // new.target would be better than this.constructor,                                                       // 37
        // but isn’t supported by Babel                                                                            // 38
        if ({}.hasOwnProperty.call(this.constructor, INITIALIZED)) {                                               // 39
            throw new Error('Enum classes can’t be instantiated');                                                 // 40
        }                                                                                                          // 41
        if ((typeof instanceProperties === 'undefined' ? 'undefined' : _typeof(instanceProperties)) === 'object' && instanceProperties !== null) {
            copyProperties(this, instanceProperties);                                                              // 43
        }                                                                                                          // 44
    }                                                                                                              // 45
    /**                                                                                                            // 46
     * Set up the enum, close the class.                                                                           // 47
     *                                                                                                             // 48
     * @param arg Either an object whose properties provide the names                                              // 49
     * and values (which must be mutable objects) of the enum constants.                                           // 50
     * Or an Array whose elements are used as the names of the enum constants                                      // 51
     * The values are create by instantiating the current class.                                                   // 52
     */                                                                                                            // 53
                                                                                                                   // 54
    _createClass(Enum, [{                                                                                          // 55
        key: 'toString',                                                                                           // 56
                                                                                                                   // 57
        /**                                                                                                        // 58
         * Default `toString()` method for enum constant.                                                          // 59
         */                                                                                                        // 60
        value: function toString() {                                                                               // 61
            return this.constructor.name + '.' + this.name;                                                        // 62
        }                                                                                                          // 63
    }], [{                                                                                                         // 64
        key: 'initEnum',                                                                                           // 65
        value: function initEnum(arg) {                                                                            // 66
            Object.defineProperty(this, 'enumValues', {                                                            // 67
                value: [],                                                                                         // 68
                configurable: false,                                                                               // 69
                writable: false,                                                                                   // 70
                enumerable: true                                                                                   // 71
            });                                                                                                    // 72
            if (Array.isArray(arg)) {                                                                              // 73
                this._enumValuesFromArray(arg);                                                                    // 74
            } else {                                                                                               // 75
                this._enumValuesFromObject(arg);                                                                   // 76
            }                                                                                                      // 77
            Object.freeze(this.enumValues);                                                                        // 78
            this[INITIALIZED] = true;                                                                              // 79
            return this;                                                                                           // 80
        }                                                                                                          // 81
    }, {                                                                                                           // 82
        key: '_enumValuesFromArray',                                                                               // 83
        value: function _enumValuesFromArray(arr) {                                                                // 84
            var _iteratorNormalCompletion = true;                                                                  // 85
            var _didIteratorError = false;                                                                         // 86
            var _iteratorError = undefined;                                                                        // 87
                                                                                                                   // 88
            try {                                                                                                  // 89
                for (var _iterator = arr[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var key = _step.value;                                                                         // 91
                                                                                                                   // 92
                    this._pushEnumValue(new this(), key);                                                          // 93
                }                                                                                                  // 94
            } catch (err) {                                                                                        // 95
                _didIteratorError = true;                                                                          // 96
                _iteratorError = err;                                                                              // 97
            } finally {                                                                                            // 98
                try {                                                                                              // 99
                    if (!_iteratorNormalCompletion && _iterator.return) {                                          // 100
                        _iterator.return();                                                                        // 101
                    }                                                                                              // 102
                } finally {                                                                                        // 103
                    if (_didIteratorError) {                                                                       // 104
                        throw _iteratorError;                                                                      // 105
                    }                                                                                              // 106
                }                                                                                                  // 107
            }                                                                                                      // 108
        }                                                                                                          // 109
    }, {                                                                                                           // 110
        key: '_enumValuesFromObject',                                                                              // 111
        value: function _enumValuesFromObject(obj) {                                                               // 112
            var _iteratorNormalCompletion2 = true;                                                                 // 113
            var _didIteratorError2 = false;                                                                        // 114
            var _iteratorError2 = undefined;                                                                       // 115
                                                                                                                   // 116
            try {                                                                                                  // 117
                for (var _iterator2 = Object.keys(obj)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                    var key = _step2.value;                                                                        // 119
                                                                                                                   // 120
                    var value = new this(obj[key]);                                                                // 121
                    this._pushEnumValue(value, key);                                                               // 122
                }                                                                                                  // 123
            } catch (err) {                                                                                        // 124
                _didIteratorError2 = true;                                                                         // 125
                _iteratorError2 = err;                                                                             // 126
            } finally {                                                                                            // 127
                try {                                                                                              // 128
                    if (!_iteratorNormalCompletion2 && _iterator2.return) {                                        // 129
                        _iterator2.return();                                                                       // 130
                    }                                                                                              // 131
                } finally {                                                                                        // 132
                    if (_didIteratorError2) {                                                                      // 133
                        throw _iteratorError2;                                                                     // 134
                    }                                                                                              // 135
                }                                                                                                  // 136
            }                                                                                                      // 137
        }                                                                                                          // 138
    }, {                                                                                                           // 139
        key: '_pushEnumValue',                                                                                     // 140
        value: function _pushEnumValue(enumValue, name) {                                                          // 141
            enumValue.name = name;                                                                                 // 142
            enumValue.ordinal = this.enumValues.length;                                                            // 143
            Object.defineProperty(this, name, {                                                                    // 144
                value: enumValue,                                                                                  // 145
                configurable: false,                                                                               // 146
                writable: false,                                                                                   // 147
                enumerable: true                                                                                   // 148
            });                                                                                                    // 149
            this.enumValues.push(enumValue);                                                                       // 150
        }                                                                                                          // 151
                                                                                                                   // 152
        /**                                                                                                        // 153
         * Given the name of an enum constant, return its value.                                                   // 154
         */                                                                                                        // 155
                                                                                                                   // 156
    }, {                                                                                                           // 157
        key: 'enumValueOf',                                                                                        // 158
        value: function enumValueOf(name) {                                                                        // 159
            return this.enumValues.find(function (x) {                                                             // 160
                return x.name === name;                                                                            // 161
            });                                                                                                    // 162
        }                                                                                                          // 163
                                                                                                                   // 164
        /**                                                                                                        // 165
         * Make enum classes iterable                                                                              // 166
         */                                                                                                        // 167
                                                                                                                   // 168
    }, {                                                                                                           // 169
        key: Symbol.iterator,                                                                                      // 170
        value: function value() {                                                                                  // 171
            return this.enumValues[Symbol.iterator]();                                                             // 172
        }                                                                                                          // 173
    }]);                                                                                                           // 174
                                                                                                                   // 175
    return Enum;                                                                                                   // 176
}();                                                                                                               // 177
                                                                                                                   // 178
function copyProperties(target, source) {                                                                          // 179
    // Ideally, we’d use Reflect.ownKeys() here,                                                                   // 180
    // but I don’t want to depend on a polyfill                                                                    // 181
    var _iteratorNormalCompletion3 = true;                                                                         // 182
    var _didIteratorError3 = false;                                                                                // 183
    var _iteratorError3 = undefined;                                                                               // 184
                                                                                                                   // 185
    try {                                                                                                          // 186
        for (var _iterator3 = Object.getOwnPropertyNames(source)[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var key = _step3.value;                                                                                // 188
                                                                                                                   // 189
            var desc = Object.getOwnPropertyDescriptor(source, key);                                               // 190
            Object.defineProperty(target, key, desc);                                                              // 191
        }                                                                                                          // 192
    } catch (err) {                                                                                                // 193
        _didIteratorError3 = true;                                                                                 // 194
        _iteratorError3 = err;                                                                                     // 195
    } finally {                                                                                                    // 196
        try {                                                                                                      // 197
            if (!_iteratorNormalCompletion3 && _iterator3.return) {                                                // 198
                _iterator3.return();                                                                               // 199
            }                                                                                                      // 200
        } finally {                                                                                                // 201
            if (_didIteratorError3) {                                                                              // 202
                throw _iteratorError3;                                                                             // 203
            }                                                                                                      // 204
        }                                                                                                          // 205
    }                                                                                                              // 206
                                                                                                                   // 207
    return target;                                                                                                 // 208
}                                                                                                                  // 209
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"dr-seeder":{"index.js":["./dist/index",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/index.js                                                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.exports = require('./dist/index');                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"dist":{"index.js":["babel-runtime/core-js/object/assign","babel-runtime/helpers/classCallCheck","babel-runtime/helpers/createClass",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/dist/index.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
'use strict';                                                                                                      // 1
                                                                                                                   // 2
Object.defineProperty(exports, "__esModule", {                                                                     // 3
  value: true                                                                                                      // 4
});                                                                                                                // 5
                                                                                                                   // 6
var _assign = require('babel-runtime/core-js/object/assign');                                                      // 7
                                                                                                                   // 8
var _assign2 = _interopRequireDefault(_assign);                                                                    // 9
                                                                                                                   // 10
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                            // 11
                                                                                                                   // 12
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                   // 13
                                                                                                                   // 14
var _createClass2 = require('babel-runtime/helpers/createClass');                                                  // 15
                                                                                                                   // 16
var _createClass3 = _interopRequireDefault(_createClass2);                                                         // 17
                                                                                                                   // 18
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }                    // 19
                                                                                                                   // 20
var Seed = function () {                                                                                           // 21
  function Seed(name, collection, options) {                                                                       // 22
    (0, _classCallCheck3.default)(this, Seed);                                                                     // 23
                                                                                                                   // 24
    if (!collection || !options) {                                                                                 // 25
      var msg = 'Please supply a collection to seed and options for seeding.';                                     // 26
      throw new Error(msg);                                                                                        // 27
    } else {                                                                                                       // 28
      this.name = name;                                                                                            // 29
      this.collection = collection;                                                                                // 30
      this.options = options;                                                                                      // 31
      this.isDataArray = this.options.data instanceof Array;                                                       // 32
      this.context = {                                                                                             // 33
        name: name,                                                                                                // 34
        collection: collection,                                                                                    // 35
        startResponse: null                                                                                        // 36
      };                                                                                                           // 37
                                                                                                                   // 38
      this.seed();                                                                                                 // 39
    }                                                                                                              // 40
  }                                                                                                                // 41
                                                                                                                   // 42
  (0, _createClass3.default)(Seed, [{                                                                              // 43
    key: 'shouldSeed',                                                                                             // 44
    value: function shouldSeed() {                                                                                 // 45
      var condition = this.options.condition;                                                                      // 46
                                                                                                                   // 47
      return condition ? condition.call(this.context) : true;                                                      // 48
    }                                                                                                              // 49
  }, {                                                                                                             // 50
    key: 'seed',                                                                                                   // 51
    value: function seed() {                                                                                       // 52
      var options = this.options;                                                                                  // 53
      var data = options.data;                                                                                     // 54
      var onStart = options.onStart;                                                                               // 55
      var onFinish = options.onFinish;                                                                             // 56
      var onSkip = options.onSkip;                                                                                 // 57
                                                                                                                   // 58
      if (this.shouldSeed()) {                                                                                     // 59
        if (onStart) {                                                                                             // 60
          this.context.startResponse = onStart.call(this.context);                                                 // 61
        }                                                                                                          // 62
                                                                                                                   // 63
        this.plant(data);                                                                                          // 64
                                                                                                                   // 65
        if (onFinish) {                                                                                            // 66
          onFinish.call(this.context);                                                                             // 67
        }                                                                                                          // 68
      } else if (onSkip) {                                                                                         // 69
        onSkip.call(this.context);                                                                                 // 70
      }                                                                                                            // 71
    }                                                                                                              // 72
  }, {                                                                                                             // 73
    key: 'plant',                                                                                                  // 74
    value: function plant(data) {                                                                                  // 75
      var loopLength = this._loopLength();                                                                         // 76
                                                                                                                   // 77
      for (var i = 0; i < loopLength; i++) {                                                                       // 78
        var value = this.isDataArray ? data[i] : data.call(this.context, i);                                       // 79
                                                                                                                   // 80
        this.collection.insert(value);                                                                             // 81
      }                                                                                                            // 82
    }                                                                                                              // 83
  }, {                                                                                                             // 84
    key: '_loopLength',                                                                                            // 85
    value: function _loopLength() {                                                                                // 86
      var random = function random(min, max) {                                                                     // 87
        return Math.floor(Math.random() * (max - min + 1)) + min;                                                  // 88
      };                                                                                                           // 89
                                                                                                                   // 90
      return this.isDataArray ? this.options.data.length : random(this.options.min, this.options.max);             // 91
    }                                                                                                              // 92
  }]);                                                                                                             // 93
  return Seed;                                                                                                     // 94
}();                                                                                                               // 95
                                                                                                                   // 96
var Seeder = {                                                                                                     // 97
  settings: {                                                                                                      // 98
    condition: function condition() {                                                                              // 99
      return this.collection.find().count() === 0;                                                                 // 100
    },                                                                                                             // 101
                                                                                                                   // 102
    min: 1,                                                                                                        // 103
    max: 20,                                                                                                       // 104
    onStart: function onStart() {                                                                                  // 105
      console.log('Seeder: ' + this.name + '\t => Started');                                                       // 106
    },                                                                                                             // 107
    onFinish: function onFinish() {                                                                                // 108
      console.log('Seeder: ' + this.name + '\t => Finished');                                                      // 109
    },                                                                                                             // 110
    onSkip: function onSkip() {                                                                                    // 111
      console.log('Seeder: ' + this.name + '\t => Skipped');                                                       // 112
    }                                                                                                              // 113
  },                                                                                                               // 114
                                                                                                                   // 115
  config: function config(options) {                                                                               // 116
    (0, _assign2.default)(this.settings, options);                                                                 // 117
  },                                                                                                               // 118
  seed: function seed(name, collection, options) {                                                                 // 119
    var finalOptions = (0, _assign2.default)({}, this.settings, options);                                          // 120
    return new Seed(name, collection, finalOptions);                                                               // 121
  }                                                                                                                // 122
};                                                                                                                 // 123
                                                                                                                   // 124
exports.default = Seeder;                                                                                          // 125
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"node_modules":{"babel-runtime":{"core-js":{"object":{"assign.js":["core-js/library/fn/object/assign",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/core-js/object/assign.js                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.exports = { "default": require("core-js/library/fn/object/assign"), __esModule: true };                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"define-property.js":["core-js/library/fn/object/define-property",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/core-js/object/define-property.js                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.exports = { "default": require("core-js/library/fn/object/define-property"), __esModule: true };            // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"node_modules":{"core-js":{"library":{"fn":{"object":{"assign.js":["../../modules/es6.object.assign","../../modules/$.core",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/fn/object/assign.js              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
require('../../modules/es6.object.assign');                                                                        // 1
module.exports = require('../../modules/$.core').Object.assign;                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"define-property.js":["../../modules/$",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/fn/object/define-property.js     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var $ = require('../../modules/$');                                                                                // 1
module.exports = function defineProperty(it, key, desc){                                                           // 2
  return $.setDesc(it, key, desc);                                                                                 // 3
};                                                                                                                 // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"modules":{"es6.object.assign.js":["./$.export","./$.object-assign",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/es6.object.assign.js     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// 19.1.3.1 Object.assign(target, source)                                                                          // 1
var $export = require('./$.export');                                                                               // 2
                                                                                                                   // 3
$export($export.S + $export.F, 'Object', {assign: require('./$.object-assign')});                                  // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"$.export.js":["./$.global","./$.core","./$.ctx",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.export.js              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var global    = require('./$.global')                                                                              // 1
  , core      = require('./$.core')                                                                                // 2
  , ctx       = require('./$.ctx')                                                                                 // 3
  , PROTOTYPE = 'prototype';                                                                                       // 4
                                                                                                                   // 5
var $export = function(type, name, source){                                                                        // 6
  var IS_FORCED = type & $export.F                                                                                 // 7
    , IS_GLOBAL = type & $export.G                                                                                 // 8
    , IS_STATIC = type & $export.S                                                                                 // 9
    , IS_PROTO  = type & $export.P                                                                                 // 10
    , IS_BIND   = type & $export.B                                                                                 // 11
    , IS_WRAP   = type & $export.W                                                                                 // 12
    , exports   = IS_GLOBAL ? core : core[name] || (core[name] = {})                                               // 13
    , target    = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE]                  // 14
    , key, own, out;                                                                                               // 15
  if(IS_GLOBAL)source = name;                                                                                      // 16
  for(key in source){                                                                                              // 17
    // contains in native                                                                                          // 18
    own = !IS_FORCED && target && key in target;                                                                   // 19
    if(own && key in exports)continue;                                                                             // 20
    // export native or passed                                                                                     // 21
    out = own ? target[key] : source[key];                                                                         // 22
    // prevent global pollution for namespaces                                                                     // 23
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]                                     // 24
    // bind timers to global for call from export context                                                          // 25
    : IS_BIND && own ? ctx(out, global)                                                                            // 26
    // wrap global constructors for prevent change them in library                                                 // 27
    : IS_WRAP && target[key] == out ? (function(C){                                                                // 28
      var F = function(param){                                                                                     // 29
        return this instanceof C ? new C(param) : C(param);                                                        // 30
      };                                                                                                           // 31
      F[PROTOTYPE] = C[PROTOTYPE];                                                                                 // 32
      return F;                                                                                                    // 33
    // make static versions for prototype methods                                                                  // 34
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;                                // 35
    if(IS_PROTO)(exports[PROTOTYPE] || (exports[PROTOTYPE] = {}))[key] = out;                                      // 36
  }                                                                                                                // 37
};                                                                                                                 // 38
// type bitmap                                                                                                     // 39
$export.F = 1;  // forced                                                                                          // 40
$export.G = 2;  // global                                                                                          // 41
$export.S = 4;  // static                                                                                          // 42
$export.P = 8;  // proto                                                                                           // 43
$export.B = 16; // bind                                                                                            // 44
$export.W = 32; // wrap                                                                                            // 45
module.exports = $export;                                                                                          // 46
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"$.global.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.global.js              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028                                            // 1
var global = module.exports = typeof window != 'undefined' && window.Math == Math                                  // 2
  ? window : typeof self != 'undefined' && self.Math == Math ? self : Function('return this')();                   // 3
if(typeof __g == 'number')__g = global; // eslint-disable-line no-undef                                            // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"$.core.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.core.js                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var core = module.exports = {version: '1.2.6'};                                                                    // 1
if(typeof __e == 'number')__e = core; // eslint-disable-line no-undef                                              // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"$.ctx.js":["./$.a-function",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.ctx.js                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// optional / simple context binding                                                                               // 1
var aFunction = require('./$.a-function');                                                                         // 2
module.exports = function(fn, that, length){                                                                       // 3
  aFunction(fn);                                                                                                   // 4
  if(that === undefined)return fn;                                                                                 // 5
  switch(length){                                                                                                  // 6
    case 1: return function(a){                                                                                    // 7
      return fn.call(that, a);                                                                                     // 8
    };                                                                                                             // 9
    case 2: return function(a, b){                                                                                 // 10
      return fn.call(that, a, b);                                                                                  // 11
    };                                                                                                             // 12
    case 3: return function(a, b, c){                                                                              // 13
      return fn.call(that, a, b, c);                                                                               // 14
    };                                                                                                             // 15
  }                                                                                                                // 16
  return function(/* ...args */){                                                                                  // 17
    return fn.apply(that, arguments);                                                                              // 18
  };                                                                                                               // 19
};                                                                                                                 // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"$.a-function.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.a-function.js          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.exports = function(it){                                                                                     // 1
  if(typeof it != 'function')throw TypeError(it + ' is not a function!');                                          // 2
  return it;                                                                                                       // 3
};                                                                                                                 // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"$.object-assign.js":["./$","./$.to-object","./$.iobject","./$.fails",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.object-assign.js       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// 19.1.2.1 Object.assign(target, source, ...)                                                                     // 1
var $        = require('./$')                                                                                      // 2
  , toObject = require('./$.to-object')                                                                            // 3
  , IObject  = require('./$.iobject');                                                                             // 4
                                                                                                                   // 5
// should work with symbols and should have deterministic property order (V8 bug)                                  // 6
module.exports = require('./$.fails')(function(){                                                                  // 7
  var a = Object.assign                                                                                            // 8
    , A = {}                                                                                                       // 9
    , B = {}                                                                                                       // 10
    , S = Symbol()                                                                                                 // 11
    , K = 'abcdefghijklmnopqrst';                                                                                  // 12
  A[S] = 7;                                                                                                        // 13
  K.split('').forEach(function(k){ B[k] = k; });                                                                   // 14
  return a({}, A)[S] != 7 || Object.keys(a({}, B)).join('') != K;                                                  // 15
}) ? function assign(target, source){ // eslint-disable-line no-unused-vars                                        // 16
  var T     = toObject(target)                                                                                     // 17
    , $$    = arguments                                                                                            // 18
    , $$len = $$.length                                                                                            // 19
    , index = 1                                                                                                    // 20
    , getKeys    = $.getKeys                                                                                       // 21
    , getSymbols = $.getSymbols                                                                                    // 22
    , isEnum     = $.isEnum;                                                                                       // 23
  while($$len > index){                                                                                            // 24
    var S      = IObject($$[index++])                                                                              // 25
      , keys   = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S)                                        // 26
      , length = keys.length                                                                                       // 27
      , j      = 0                                                                                                 // 28
      , key;                                                                                                       // 29
    while(length > j)if(isEnum.call(S, key = keys[j++]))T[key] = S[key];                                           // 30
  }                                                                                                                // 31
  return T;                                                                                                        // 32
} : Object.assign;                                                                                                 // 33
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"$.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.js                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var $Object = Object;                                                                                              // 1
module.exports = {                                                                                                 // 2
  create:     $Object.create,                                                                                      // 3
  getProto:   $Object.getPrototypeOf,                                                                              // 4
  isEnum:     {}.propertyIsEnumerable,                                                                             // 5
  getDesc:    $Object.getOwnPropertyDescriptor,                                                                    // 6
  setDesc:    $Object.defineProperty,                                                                              // 7
  setDescs:   $Object.defineProperties,                                                                            // 8
  getKeys:    $Object.keys,                                                                                        // 9
  getNames:   $Object.getOwnPropertyNames,                                                                         // 10
  getSymbols: $Object.getOwnPropertySymbols,                                                                       // 11
  each:       [].forEach                                                                                           // 12
};                                                                                                                 // 13
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"$.to-object.js":["./$.defined",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.to-object.js           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// 7.1.13 ToObject(argument)                                                                                       // 1
var defined = require('./$.defined');                                                                              // 2
module.exports = function(it){                                                                                     // 3
  return Object(defined(it));                                                                                      // 4
};                                                                                                                 // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"$.defined.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.defined.js             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// 7.2.1 RequireObjectCoercible(argument)                                                                          // 1
module.exports = function(it){                                                                                     // 2
  if(it == undefined)throw TypeError("Can't call method on  " + it);                                               // 3
  return it;                                                                                                       // 4
};                                                                                                                 // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"$.iobject.js":["./$.cof",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.iobject.js             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// fallback for non-array-like ES3 and non-enumerable old V8 strings                                               // 1
var cof = require('./$.cof');                                                                                      // 2
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function(it){                                      // 3
  return cof(it) == 'String' ? it.split('') : Object(it);                                                          // 4
};                                                                                                                 // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"$.cof.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.cof.js                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var toString = {}.toString;                                                                                        // 1
                                                                                                                   // 2
module.exports = function(it){                                                                                     // 3
  return toString.call(it).slice(8, -1);                                                                           // 4
};                                                                                                                 // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"$.fails.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/node_modules/core-js/library/modules/$.fails.js               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.exports = function(exec){                                                                                   // 1
  try {                                                                                                            // 2
    return !!exec();                                                                                               // 3
  } catch(e){                                                                                                      // 4
    return true;                                                                                                   // 5
  }                                                                                                                // 6
};                                                                                                                 // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},"helpers":{"classCallCheck.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/helpers/classCallCheck.js                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
"use strict";                                                                                                      // 1
                                                                                                                   // 2
exports.__esModule = true;                                                                                         // 3
                                                                                                                   // 4
exports.default = function (instance, Constructor) {                                                               // 5
  if (!(instance instanceof Constructor)) {                                                                        // 6
    throw new TypeError("Cannot call a class as a function");                                                      // 7
  }                                                                                                                // 8
};                                                                                                                 // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"createClass.js":["../core-js/object/define-property",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/dr-seeder/node_modules/babel-runtime/helpers/createClass.js                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
"use strict";                                                                                                      // 1
                                                                                                                   // 2
exports.__esModule = true;                                                                                         // 3
                                                                                                                   // 4
var _defineProperty = require("../core-js/object/define-property");                                                // 5
                                                                                                                   // 6
var _defineProperty2 = _interopRequireDefault(_defineProperty);                                                    // 7
                                                                                                                   // 8
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }                    // 9
                                                                                                                   // 10
exports.default = function () {                                                                                    // 11
  function defineProperties(target, props) {                                                                       // 12
    for (var i = 0; i < props.length; i++) {                                                                       // 13
      var descriptor = props[i];                                                                                   // 14
      descriptor.enumerable = descriptor.enumerable || false;                                                      // 15
      descriptor.configurable = true;                                                                              // 16
      if ("value" in descriptor) descriptor.writable = true;                                                       // 17
      (0, _defineProperty2.default)(target, descriptor.key, descriptor);                                           // 18
    }                                                                                                              // 19
  }                                                                                                                // 20
                                                                                                                   // 21
  return function (Constructor, protoProps, staticProps) {                                                         // 22
    if (protoProps) defineProperties(Constructor.prototype, protoProps);                                           // 23
    if (staticProps) defineProperties(Constructor, staticProps);                                                   // 24
    return Constructor;                                                                                            // 25
  };                                                                                                               // 26
}();                                                                                                               // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}}});
require("./lib/collections/buildings.js");
require("./lib/collections/cleaners.js");
require("./lib/collections/index.js");
require("./lib/collections/jobs.js");
require("./lib/collections/schedules.js");
require("./lib/helpers.js");
require("./lib/weekdays.js");
require("./server/cron/index.js");
require("./server/methods/buildings.js");
require("./server/methods/cleaners.js");
require("./server/methods/jobs.js");
require("./server/publications/all.js");
require("./server/seed/startup.js");
require("./server/migrations.js");
require("./server/schedule.js");
require("./server/scheduleEditor.js");
require("./server/security.js");
//# sourceMappingURL=app.js.map
