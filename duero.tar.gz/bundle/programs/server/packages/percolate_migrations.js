(function () {

/* Imports */
var process = Package.meteor.process;
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Log = Package.logging.Log;

/* Package-scope variables */
var Migrations;

(function(){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/percolate_migrations/migrations_server.js                               //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
/*                                                                                  // 1
  Adds migration capabilities. Migrations are defined like:                         // 2
                                                                                    // 3
  Migrations.add({                                                                  // 4
    up: function() {}, //*required* code to run to migrate upwards                  // 5
    version: 1, //*required* number to identify migration order                     // 6
    down: function() {}, //*optional* code to run to migrate downwards              // 7
    name: 'Something' //*optional* display name for the migration                   // 8
  });                                                                               // 9
                                                                                    // 10
  The ordering of migrations is determined by the version you set.                  // 11
                                                                                    // 12
  To run the migrations, set the MIGRATE environment variable to either             // 13
  'latest' or the version number you want to migrate to. Optionally, append         // 14
  ',exit' if you want the migrations to exit the meteor process, e.g if you're      // 15
  migrating from a script (remember to pass the --once parameter).                  // 16
                                                                                    // 17
  e.g:                                                                              // 18
  MIGRATE="latest" mrt # ensure we'll be at the latest version and run the app      // 19
  MIGRATE="latest,exit" mrt --once # ensure we'll be at the latest version and exit
  MIGRATE="2,exit" mrt --once # migrate to version 2 and exit                       // 21
                                                                                    // 22
  Note: Migrations will lock ensuring only 1 app can be migrating at once. If       // 23
  a migration crashes, the control record in the migrations collection will         // 24
  remain locked and at the version it was at previously, however the db could       // 25
  be in an inconsistant state.                                                      // 26
*/                                                                                  // 27
                                                                                    // 28
// since we'll be at version 0 by default, we should have a migration set for       // 29
// it.                                                                              // 30
var DefaultMigration = {version: 0, up: function(){}};                              // 31
                                                                                    // 32
Migrations = {                                                                      // 33
  _list: [DefaultMigration],                                                        // 34
  options: {                                                                        // 35
    // false disables logging                                                       // 36
    log: true,                                                                      // 37
    // null or a function                                                           // 38
    logger: null,                                                                   // 39
    // enable/disable info log "already at latest."                                 // 40
    logIfLatest: true,                                                              // 41
    // migrations collection name                                                   // 42
    collectionName: "migrations"                                                    // 43
  },                                                                                // 44
  config: function(opts) {                                                          // 45
    this.options = _.extend({}, this.options, opts);                                // 46
  },                                                                                // 47
}                                                                                   // 48
                                                                                    // 49
/*                                                                                  // 50
  Logger factory function. Takes a prefix string and options object                 // 51
  and uses an injected `logger` if provided, else falls back to                     // 52
  Meteor's `Log` package.                                                           // 53
  Will send a log object to the injected logger, on the following form:             // 54
    message: String                                                                 // 55
    level: String (info, warn, error, debug)                                        // 56
    tag: 'Migrations'                                                               // 57
*/                                                                                  // 58
function createLogger(prefix) {                                                     // 59
  check(prefix, String);                                                            // 60
                                                                                    // 61
  // Return noop if logging is disabled.                                            // 62
  if(Migrations.options.log === false) {                                            // 63
    return function() {};                                                           // 64
  }                                                                                 // 65
                                                                                    // 66
  return function(level, message) {                                                 // 67
    check(level, Match.OneOf('info', 'error', 'warn', 'debug'));                    // 68
    check(message, String);                                                         // 69
                                                                                    // 70
    var logger = Migrations.options && Migrations.options.logger;                   // 71
                                                                                    // 72
    if(logger && _.isFunction(logger)) {                                            // 73
                                                                                    // 74
      logger({                                                                      // 75
        level: level,                                                               // 76
        message: message,                                                           // 77
        tag: prefix                                                                 // 78
      });                                                                           // 79
                                                                                    // 80
    } else {                                                                        // 81
      Log[level]({ message: prefix + ': ' + message });                             // 82
    }                                                                               // 83
  }                                                                                 // 84
}                                                                                   // 85
                                                                                    // 86
var log;                                                                            // 87
                                                                                    // 88
Meteor.startup(function () {                                                        // 89
  var options = Migrations.options;                                                 // 90
                                                                                    // 91
  // collection holding the control record                                          // 92
  Migrations._collection = new Mongo.Collection(options.collectionName);            // 93
                                                                                    // 94
  log = createLogger('Migrations');                                                 // 95
                                                                                    // 96
  ['info', 'warn', 'error', 'debug'].forEach(function(level) {                      // 97
    log[level] = _.partial(log, level);                                             // 98
  });                                                                               // 99
                                                                                    // 100
  if (process.env.MIGRATE)                                                          // 101
    Migrations.migrateTo(process.env.MIGRATE);                                      // 102
});                                                                                 // 103
                                                                                    // 104
// Add a new migration:                                                             // 105
// {up: function *required                                                          // 106
//  version: Number *required                                                       // 107
//  down: function *optional                                                        // 108
//  name: String *optional                                                          // 109
// }                                                                                // 110
Migrations.add = function(migration) {                                              // 111
  if (typeof migration.up !== 'function')                                           // 112
    throw new Meteor.Error('Migration must supply an up function.');                // 113
                                                                                    // 114
  if (typeof migration.version !== 'number')                                        // 115
    throw new Meteor.Error('Migration must supply a version number.');              // 116
                                                                                    // 117
  if (migration.version <= 0)                                                       // 118
    throw new Meteor.Error('Migration version must be greater than 0');             // 119
                                                                                    // 120
  // Freeze the migration object to make it hereafter immutable                     // 121
  Object.freeze(migration);                                                         // 122
                                                                                    // 123
  this._list.push(migration);                                                       // 124
  this._list = _.sortBy(this._list, function(m) {return m.version;});               // 125
}                                                                                   // 126
                                                                                    // 127
// Attempts to run the migrations using command in the form of:                     // 128
// e.g 'latest', 'latest,exit', 2                                                   // 129
// use 'XX,rerun' to re-run the migration at that version                           // 130
Migrations.migrateTo = function(command) {                                          // 131
  if (_.isUndefined(command) || command === '' || this._list.length === 0)          // 132
    throw new Error("Cannot migrate using invalid command: " + command);            // 133
                                                                                    // 134
  if (typeof command === 'number') {                                                // 135
    var version = command;                                                          // 136
  } else {                                                                          // 137
    var version = command.split(',')[0];                                            // 138
    var subcommand = command.split(',')[1];                                         // 139
  }                                                                                 // 140
                                                                                    // 141
  if (version === 'latest') {                                                       // 142
    this._migrateTo(_.last(this._list).version);                                    // 143
  } else {                                                                          // 144
    this._migrateTo(parseInt(version), (subcommand === 'rerun'));                   // 145
  }                                                                                 // 146
                                                                                    // 147
  // remember to run meteor with --once otherwise it will restart                   // 148
  if (subcommand === 'exit')                                                        // 149
    process.exit(0);                                                                // 150
}                                                                                   // 151
                                                                                    // 152
// just returns the current version                                                 // 153
Migrations.getVersion = function() {                                                // 154
  return this._getControl().version;                                                // 155
}                                                                                   // 156
                                                                                    // 157
// migrates to the specific version passed in                                       // 158
Migrations._migrateTo = function(version, rerun) {                                  // 159
  var self = this;                                                                  // 160
  var control = this._getControl(); // Side effect: upserts control document.       // 161
  var currentVersion = control.version;                                             // 162
                                                                                    // 163
  if (lock() === false) {                                                           // 164
    log.info('Not migrating, control is locked.');                                  // 165
    return;                                                                         // 166
  }                                                                                 // 167
                                                                                    // 168
  if (rerun) {                                                                      // 169
    log.info('Rerunning version ' + version);                                       // 170
    migrate('up', version);                                                         // 171
    log.info('Finished migrating.');                                                // 172
    unlock();                                                                       // 173
    return;                                                                         // 174
  }                                                                                 // 175
                                                                                    // 176
  if (currentVersion === version) {                                                 // 177
    if (Migrations.options.logIfLatest) {                                           // 178
      log.info('Not migrating, already at version ' + version);                     // 179
    }                                                                               // 180
    unlock();                                                                       // 181
    return;                                                                         // 182
  }                                                                                 // 183
                                                                                    // 184
  var startIdx = this._findIndexByVersion(currentVersion);                          // 185
  var endIdx = this._findIndexByVersion(version);                                   // 186
                                                                                    // 187
  // log.info('startIdx:' + startIdx + ' endIdx:' + endIdx);                        // 188
  log.info('Migrating from version ' + this._list[startIdx].version                 // 189
    + ' -> ' + this._list[endIdx].version);                                         // 190
                                                                                    // 191
  // run the actual migration                                                       // 192
  function migrate(direction, idx) {                                                // 193
    var migration = self._list[idx];                                                // 194
                                                                                    // 195
    if (typeof migration[direction] !== 'function') {                               // 196
      unlock();                                                                     // 197
      throw new Meteor.Error('Cannot migrate ' + direction + ' on version '         // 198
        + migration.version);                                                       // 199
    }                                                                               // 200
                                                                                    // 201
    function maybeName() {                                                          // 202
      return migration.name ? ' (' + migration.name + ')' : '';                     // 203
    }                                                                               // 204
                                                                                    // 205
    log.info('Running ' + direction + '() on version '                              // 206
      + migration.version + maybeName());                                           // 207
                                                                                    // 208
    migration[direction](migration);                                                // 209
  }                                                                                 // 210
                                                                                    // 211
  // Returns true if lock was acquired.                                             // 212
  function lock() {                                                                 // 213
    // This is atomic. The selector ensures only one caller at a time will see      // 214
    // the unlocked control, and locking occurs in the same update's modifier.      // 215
    // All other simultaneous callers will get false back from the update.          // 216
    return self._collection.update(                                                 // 217
      {_id: 'control', locked: false}, {$set: {locked: true, lockedAt: new Date()}}
    ) === 1;                                                                        // 219
  }                                                                                 // 220
                                                                                    // 221
  // Side effect: saves version.                                                    // 222
  function unlock() {                                                               // 223
    self._setControl({locked: false, version: currentVersion});                     // 224
  }                                                                                 // 225
                                                                                    // 226
  if (currentVersion < version) {                                                   // 227
    for (var i = startIdx;i < endIdx;i++) {                                         // 228
      migrate('up', i + 1);                                                         // 229
      currentVersion = self._list[i + 1].version;                                   // 230
    }                                                                               // 231
  } else {                                                                          // 232
    for (var i = startIdx;i > endIdx;i--) {                                         // 233
      migrate('down', i);                                                           // 234
      currentVersion = self._list[i - 1].version;                                   // 235
    }                                                                               // 236
  }                                                                                 // 237
                                                                                    // 238
  unlock();                                                                         // 239
  log.info('Finished migrating.');                                                  // 240
}                                                                                   // 241
                                                                                    // 242
// gets the current control record, optionally creating it if non-existant          // 243
Migrations._getControl = function() {                                               // 244
  var control = this._collection.findOne({_id: 'control'});                         // 245
                                                                                    // 246
  return control || this._setControl({version: 0, locked: false});                  // 247
}                                                                                   // 248
                                                                                    // 249
// sets the control record                                                          // 250
Migrations._setControl = function(control) {                                        // 251
  // be quite strict                                                                // 252
  check(control.version, Number);                                                   // 253
  check(control.locked, Boolean);                                                   // 254
                                                                                    // 255
  this._collection.update({_id: 'control'},                                         // 256
    {$set: {version: control.version, locked: control.locked}}, {upsert: true});    // 257
                                                                                    // 258
  return control;                                                                   // 259
}                                                                                   // 260
                                                                                    // 261
// returns the migration index in _list or throws if not found                      // 262
Migrations._findIndexByVersion = function(version) {                                // 263
  for (var i = 0;i < this._list.length;i++) {                                       // 264
    if (this._list[i].version === version)                                          // 265
      return i;                                                                     // 266
  }                                                                                 // 267
                                                                                    // 268
  throw new Meteor.Error('Can\'t find migration version ' + version);               // 269
}                                                                                   // 270
                                                                                    // 271
//reset (mainly intended for tests)                                                 // 272
Migrations._reset = function() {                                                    // 273
  this._list = [{version: 0, up: function(){}}];                                    // 274
  this._collection.remove({});                                                      // 275
}                                                                                   // 276
                                                                                    // 277
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['percolate:migrations'] = {}, {
  Migrations: Migrations
});

})();

//# sourceMappingURL=percolate_migrations.js.map
