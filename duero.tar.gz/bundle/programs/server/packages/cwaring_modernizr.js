(function () {

/* Imports */
var process = Package.meteor.process;
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/cwaring_modernizr/packages/cwaring_modernizr.js          //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cwaring:modernizr'] = {};

})();

//# sourceMappingURL=cwaring_modernizr.js.map
