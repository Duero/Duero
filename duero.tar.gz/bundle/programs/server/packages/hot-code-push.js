(function () {

/* Imports */
var process = Package.meteor.process;
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hot-code-push'] = {};

})();

//# sourceMappingURL=hot-code-push.js.map
