(function () {

/* Imports */
var process = Package.meteor.process;
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var _ = Package.underscore._;
var moment = Package['momentjs:moment'].moment;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/oaf_moment-duration-format/packages/oaf_moment-duration-format.js                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {                                                                                                         // 1
                                                                                                                       // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                                               //    // 4
// packages/oaf:moment-duration-format/compatibility.js                                                          //    // 5
//                                                                                                               //    // 6
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                                                 //    // 8
this._ = Package.underscore._;                                                                                   // 1  // 9
this.moment = Package['momentjs:moment'].moment;                                                                 // 2  // 10
                                                                                                                 // 3  // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 12
                                                                                                                       // 13
}).call(this);                                                                                                         // 14
                                                                                                                       // 15
                                                                                                                       // 16
                                                                                                                       // 17
                                                                                                                       // 18
                                                                                                                       // 19
                                                                                                                       // 20
(function () {                                                                                                         // 21
                                                                                                                       // 22
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 23
//                                                                                                               //    // 24
// packages/oaf:moment-duration-format/lib/moment-duration-format/lib/moment-duration-format.js                  //    // 25
//                                                                                                               //    // 26
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 27
                                                                                                                 //    // 28
/*! Moment Duration Format v1.3.0                                                                                // 1  // 29
 *  https://github.com/jsmreese/moment-duration-format                                                           // 2  // 30
 *  Date: 2014-07-15                                                                                             // 3  // 31
 *                                                                                                               // 4  // 32
 *  Duration format plugin function for the Moment.js library                                                    // 5  // 33
 *  http://momentjs.com/                                                                                         // 6  // 34
 *                                                                                                               // 7  // 35
 *  Copyright 2014 John Madhavan-Reese                                                                           // 8  // 36
 *  Released under the MIT license                                                                               // 9  // 37
 */                                                                                                              // 10
                                                                                                                 // 11
(function (root, undefined) {                                                                                    // 12
                                                                                                                 // 13
	// repeatZero(qty)                                                                                              // 14
	// returns "0" repeated qty times                                                                               // 15
	function repeatZero(qty) {                                                                                      // 16
		var result = "";                                                                                               // 17
		                                                                                                               // 18
		// exit early                                                                                                  // 19
		// if qty is 0 or a negative number                                                                            // 20
		// or doesn't coerce to an integer                                                                             // 21
		qty = parseInt(qty, 10);                                                                                       // 22
		if (!qty || qty < 1) { return result; }                                                                        // 23
		                                                                                                               // 24
		while (qty) {                                                                                                  // 25
			result += "0";                                                                                                // 26
			qty -= 1;                                                                                                     // 27
		}                                                                                                              // 28
		                                                                                                               // 29
		return result;                                                                                                 // 30
	}                                                                                                               // 31
	                                                                                                                // 32
	// padZero(str, len [, isRight])                                                                                // 33
	// pads a string with zeros up to a specified length                                                            // 34
	// will not pad a string if its length is aready                                                                // 35
	// greater than or equal to the specified length                                                                // 36
	// default output pads with zeros on the left                                                                   // 37
	// set isRight to `true` to pad with zeros on the right                                                         // 38
	function padZero(str, len, isRight) {                                                                           // 39
		if (str == null) { str = ""; }                                                                                 // 40
		str = "" + str;                                                                                                // 41
		                                                                                                               // 42
		return (isRight ? str : "") + repeatZero(len - str.length) + (isRight ? "" : str);                             // 43
	}                                                                                                               // 44
	                                                                                                                // 45
	// isArray                                                                                                      // 46
	function isArray(array) {                                                                                       // 47
		return Object.prototype.toString.call(array) === "[object Array]";                                             // 48
	}                                                                                                               // 49
	                                                                                                                // 50
	// isObject                                                                                                     // 51
	function isObject(obj) {                                                                                        // 52
		return Object.prototype.toString.call(obj) === "[object Object]";                                              // 53
	}                                                                                                               // 54
	                                                                                                                // 55
	// findLast                                                                                                     // 56
	function findLast(array, callback) {                                                                            // 57
		var index = array.length;                                                                                      // 58
                                                                                                                 // 59
		while (index -= 1) {                                                                                           // 60
			if (callback(array[index])) { return array[index]; }                                                          // 61
		}                                                                                                              // 62
	}                                                                                                               // 63
                                                                                                                 // 64
	// find                                                                                                         // 65
	function find(array, callback) {                                                                                // 66
		var index = 0,                                                                                                 // 67
			max = array.length,                                                                                           // 68
			match;                                                                                                        // 69
			                                                                                                              // 70
		if (typeof callback !== "function") {                                                                          // 71
			match = callback;                                                                                             // 72
			callback = function (item) {                                                                                  // 73
				return item === match;                                                                                       // 74
			};                                                                                                            // 75
		}                                                                                                              // 76
                                                                                                                 // 77
		while (index < max) {                                                                                          // 78
			if (callback(array[index])) { return array[index]; }                                                          // 79
			index += 1;                                                                                                   // 80
		}                                                                                                              // 81
	}                                                                                                               // 82
	                                                                                                                // 83
	// each                                                                                                         // 84
	function each(array, callback) {                                                                                // 85
		var index = 0,                                                                                                 // 86
			max = array.length;                                                                                           // 87
			                                                                                                              // 88
		if (!array || !max) { return; }                                                                                // 89
                                                                                                                 // 90
		while (index < max) {                                                                                          // 91
			if (callback(array[index], index) === false) { return; }                                                      // 92
			index += 1;                                                                                                   // 93
		}                                                                                                              // 94
	}                                                                                                               // 95
	                                                                                                                // 96
	// map                                                                                                          // 97
	function map(array, callback) {                                                                                 // 98
		var index = 0,                                                                                                 // 99
			max = array.length,                                                                                           // 100
			ret = [];                                                                                                     // 101
                                                                                                                 // 102
		if (!array || !max) { return ret; }                                                                            // 103
				                                                                                                             // 104
		while (index < max) {                                                                                          // 105
			ret[index] = callback(array[index], index);                                                                   // 106
			index += 1;                                                                                                   // 107
		}                                                                                                              // 108
		                                                                                                               // 109
		return ret;                                                                                                    // 110
	}                                                                                                               // 111
	                                                                                                                // 112
	// pluck                                                                                                        // 113
	function pluck(array, prop) {                                                                                   // 114
		return map(array, function (item) {                                                                            // 115
			return item[prop];                                                                                            // 116
		});                                                                                                            // 117
	}                                                                                                               // 118
	                                                                                                                // 119
	// compact                                                                                                      // 120
	function compact(array) {                                                                                       // 121
		var ret = [];                                                                                                  // 122
		                                                                                                               // 123
		each(array, function (item) {                                                                                  // 124
			if (item) { ret.push(item); }                                                                                 // 125
		});                                                                                                            // 126
		                                                                                                               // 127
		return ret;                                                                                                    // 128
	}                                                                                                               // 129
	                                                                                                                // 130
	// unique                                                                                                       // 131
	function unique(array) {                                                                                        // 132
		var ret = [];                                                                                                  // 133
		                                                                                                               // 134
		each(array, function (_a) {                                                                                    // 135
			if (!find(ret, _a)) { ret.push(_a); }                                                                         // 136
		});                                                                                                            // 137
		                                                                                                               // 138
		return ret;                                                                                                    // 139
	}                                                                                                               // 140
	                                                                                                                // 141
	// intersection                                                                                                 // 142
	function intersection(a, b) {                                                                                   // 143
		var ret = [];                                                                                                  // 144
		                                                                                                               // 145
		each(a, function (_a) {                                                                                        // 146
			each(b, function (_b) {                                                                                       // 147
				if (_a === _b) { ret.push(_a); }                                                                             // 148
			});                                                                                                           // 149
		});                                                                                                            // 150
		                                                                                                               // 151
		return unique(ret);                                                                                            // 152
	}                                                                                                               // 153
	                                                                                                                // 154
	// rest                                                                                                         // 155
	function rest(array, callback) {                                                                                // 156
		var ret = [];                                                                                                  // 157
		                                                                                                               // 158
		each(array, function (item, index) {                                                                           // 159
			if (!callback(item)) {                                                                                        // 160
				ret = array.slice(index);                                                                                    // 161
				return false;                                                                                                // 162
			}                                                                                                             // 163
		});                                                                                                            // 164
		                                                                                                               // 165
		return ret;                                                                                                    // 166
	}                                                                                                               // 167
                                                                                                                 // 168
	// initial                                                                                                      // 169
	function initial(array, callback) {                                                                             // 170
		var reversed = array.slice().reverse();                                                                        // 171
		                                                                                                               // 172
		return rest(reversed, callback).reverse();                                                                     // 173
	}                                                                                                               // 174
	                                                                                                                // 175
	// extend                                                                                                       // 176
	function extend(a, b) {                                                                                         // 177
		for (var key in b) {                                                                                           // 178
			if (b.hasOwnProperty(key)) { a[key] = b[key]; }                                                               // 179
		}                                                                                                              // 180
		                                                                                                               // 181
		return a;                                                                                                      // 182
	}                                                                                                               // 183
			                                                                                                              // 184
	// define internal moment reference                                                                             // 185
	var moment;                                                                                                     // 186
                                                                                                                 // 187
	if (typeof require === "function") {                                                                            // 188
		try { moment = require('moment'); }                                                                            // 189
		catch (e) {}                                                                                                   // 190
	}                                                                                                               // 191
	                                                                                                                // 192
	if (!moment && root.moment) {                                                                                   // 193
		moment = root.moment;                                                                                          // 194
	}                                                                                                               // 195
	                                                                                                                // 196
	if (!moment) {                                                                                                  // 197
		throw "Moment Duration Format cannot find Moment.js";                                                          // 198
	}                                                                                                               // 199
	                                                                                                                // 200
	// moment.duration.format([template] [, precision] [, settings])                                                // 201
	moment.duration.fn.format = function () {                                                                       // 202
                                                                                                                 // 203
		var tokenizer, tokens, types, typeMap, momentTypes, foundFirst, trimIndex,                                     // 204
			args = [].slice.call(arguments),                                                                              // 205
			settings = extend({}, this.format.defaults),                                                                  // 206
			// keep a shadow copy of this moment for calculating remainders                                               // 207
			remainder = moment.duration(this);                                                                            // 208
                                                                                                                 // 209
		// add a reference to this duration object to the settings for use                                             // 210
		// in a template function                                                                                      // 211
		settings.duration = this;                                                                                      // 212
                                                                                                                 // 213
		// parse arguments                                                                                             // 214
		each(args, function (arg) {                                                                                    // 215
			if (typeof arg === "string" || typeof arg === "function") {                                                   // 216
				settings.template = arg;                                                                                     // 217
				return;                                                                                                      // 218
			}                                                                                                             // 219
                                                                                                                 // 220
			if (typeof arg === "number") {                                                                                // 221
				settings.precision = arg;                                                                                    // 222
				return;                                                                                                      // 223
			}                                                                                                             // 224
                                                                                                                 // 225
			if (isObject(arg)) {                                                                                          // 226
				extend(settings, arg);                                                                                       // 227
			}                                                                                                             // 228
		});                                                                                                            // 229
                                                                                                                 // 230
		// types                                                                                                       // 231
		types = settings.types = (isArray(settings.types) ? settings.types : settings.types.split(" "));               // 232
                                                                                                                 // 233
		// template                                                                                                    // 234
		if (typeof settings.template === "function") {                                                                 // 235
			settings.template = settings.template.apply(settings);                                                        // 236
		}                                                                                                              // 237
                                                                                                                 // 238
		// tokenizer regexp                                                                                            // 239
		tokenizer = new RegExp(map(types, function (type) {                                                            // 240
			return settings[type].source;                                                                                 // 241
		}).join("|"), "g");                                                                                            // 242
                                                                                                                 // 243
		// token type map function                                                                                     // 244
		typeMap = function (token) {                                                                                   // 245
			return find(types, function (type) {                                                                          // 246
				return settings[type].test(token);                                                                           // 247
			});                                                                                                           // 248
		};                                                                                                             // 249
                                                                                                                 // 250
		// tokens array                                                                                                // 251
		tokens = map(settings.template.match(tokenizer), function (token, index) {                                     // 252
			var type = typeMap(token),                                                                                    // 253
				length = token.length;                                                                                       // 254
                                                                                                                 // 255
			return {                                                                                                      // 256
				index: index,                                                                                                // 257
				length: length,                                                                                              // 258
                                                                                                                 // 259
				// replace escaped tokens with the non-escaped token text                                                    // 260
				token: (type === "escape" ? token.replace(settings.escape, "$1") : token),                                   // 261
                                                                                                                 // 262
				// ignore type on non-moment tokens                                                                          // 263
				type: ((type === "escape" || type === "general") ? null : type)                                              // 264
                                                                                                                 // 265
				// calculate base value for all moment tokens                                                                // 266
				//baseValue: ((type === "escape" || type === "general") ? null : this.as(type))                              // 267
			};                                                                                                            // 268
		}, this);                                                                                                      // 269
                                                                                                                 // 270
		// unique moment token types in the template (in order of descending magnitude)                                // 271
		momentTypes = intersection(types, unique(compact(pluck(tokens, "type"))));                                     // 272
                                                                                                                 // 273
		// exit early if there are no momentTypes                                                                      // 274
		if (!momentTypes.length) {                                                                                     // 275
			return pluck(tokens, "token").join("");                                                                       // 276
		}                                                                                                              // 277
                                                                                                                 // 278
		// calculate values for each token type in the template                                                        // 279
		each(momentTypes, function (momentType, index) {                                                               // 280
			var value, wholeValue, decimalValue, isLeast, isMost;                                                         // 281
                                                                                                                 // 282
			// calculate integer and decimal value portions                                                               // 283
			value = remainder.as(momentType);                                                                             // 284
			wholeValue = (value > 0 ? Math.floor(value) : Math.ceil(value));                                              // 285
			decimalValue = value - wholeValue;                                                                            // 286
                                                                                                                 // 287
			// is this the least-significant moment token found?                                                          // 288
			isLeast = ((index + 1) === momentTypes.length);                                                               // 289
                                                                                                                 // 290
			// is this the most-significant moment token found?                                                           // 291
			isMost = (!index);                                                                                            // 292
                                                                                                                 // 293
			// update tokens array                                                                                        // 294
			// using this algorithm to not assume anything about                                                          // 295
			// the order or frequency of any tokens                                                                       // 296
			each(tokens, function (token) {                                                                               // 297
				if (token.type === momentType) {                                                                             // 298
					extend(token, {                                                                                             // 299
						value: value,                                                                                              // 300
						wholeValue: wholeValue,                                                                                    // 301
						decimalValue: decimalValue,                                                                                // 302
						isLeast: isLeast,                                                                                          // 303
						isMost: isMost                                                                                             // 304
					});                                                                                                         // 305
                                                                                                                 // 306
					if (isMost) {                                                                                               // 307
						// note the length of the most-significant moment token:                                                   // 308
						// if it is greater than one and forceLength is not set, default forceLength to `true`                     // 309
						if (settings.forceLength == null && token.length > 1) {                                                    // 310
							settings.forceLength = true;                                                                              // 311
						}                                                                                                          // 312
                                                                                                                 // 313
						// rationale is this:                                                                                      // 314
						// if the template is "h:mm:ss" and the moment value is 5 minutes, the user-friendly output is "5:00", not "05:00"
						// shouldn't pad the `minutes` token even though it has length of two                                      // 316
						// if the template is "hh:mm:ss", the user clearly wanted everything padded so we should output "05:00"    // 317
						// if the user wanted the full padded output, they can set `{ trim: false }` to get "00:05:00"             // 318
					}                                                                                                           // 319
				}                                                                                                            // 320
			});                                                                                                           // 321
                                                                                                                 // 322
			// update remainder                                                                                           // 323
			remainder.subtract(wholeValue, momentType);                                                                   // 324
		});                                                                                                            // 325
	                                                                                                                // 326
		// trim tokens array                                                                                           // 327
		if (settings.trim) {                                                                                           // 328
			tokens = (settings.trim === "left" ? rest : initial)(tokens, function (token) {                               // 329
				// return `true` if:                                                                                         // 330
				// the token is not the least moment token (don't trim the least moment token)                               // 331
				// the token is a moment token that does not have a value (don't trim moment tokens that have a whole value) // 332
				return !(token.isLeast || (token.type != null && token.wholeValue));                                         // 333
			});                                                                                                           // 334
		}                                                                                                              // 335
		                                                                                                               // 336
		                                                                                                               // 337
		// build output                                                                                                // 338
                                                                                                                 // 339
		// the first moment token can have special handling                                                            // 340
		foundFirst = false;                                                                                            // 341
                                                                                                                 // 342
		// run the map in reverse order if trimming from the right                                                     // 343
		if (settings.trim === "right") {                                                                               // 344
			tokens.reverse();                                                                                             // 345
		}                                                                                                              // 346
                                                                                                                 // 347
		tokens = map(tokens, function (token) {                                                                        // 348
			var val,                                                                                                      // 349
				decVal;                                                                                                      // 350
                                                                                                                 // 351
			if (!token.type) {                                                                                            // 352
				// if it is not a moment token, use the token as its own value                                               // 353
				return token.token;                                                                                          // 354
			}                                                                                                             // 355
                                                                                                                 // 356
			// apply negative precision formatting to the least-significant moment token                                  // 357
			if (token.isLeast && (settings.precision < 0)) {                                                              // 358
				val = (Math.floor(token.wholeValue * Math.pow(10, settings.precision)) * Math.pow(10, -settings.precision)).toString();
			} else {                                                                                                      // 360
				val = token.wholeValue.toString();                                                                           // 361
			}                                                                                                             // 362
			                                                                                                              // 363
			// remove negative sign from the beginning                                                                    // 364
			val = val.replace(/^\-/, "");                                                                                 // 365
                                                                                                                 // 366
			// apply token length formatting                                                                              // 367
			// special handling for the first moment token that is not the most significant in a trimmed template         // 368
			if (token.length > 1 && (foundFirst || token.isMost || settings.forceLength)) {                               // 369
				val = padZero(val, token.length);                                                                            // 370
			}                                                                                                             // 371
                                                                                                                 // 372
			// add decimal value if precision > 0                                                                         // 373
			if (token.isLeast && (settings.precision > 0)) {                                                              // 374
				decVal = token.decimalValue.toString().replace(/^\-/, "").split(/\.|e\-/);                                   // 375
				switch (decVal.length) {                                                                                     // 376
					case 1:                                                                                                     // 377
						val += "." + padZero(decVal[0], settings.precision, true).slice(0, settings.precision);                    // 378
						break;                                                                                                     // 379
						                                                                                                           // 380
					case 2:                                                                                                     // 381
						val += "." + padZero(decVal[1], settings.precision, true).slice(0, settings.precision);		                  // 382
						break;                                                                                                     // 383
						                                                                                                           // 384
					case 3:                                                                                                     // 385
						val += "." + padZero(repeatZero((+decVal[2]) - 1) + (decVal[0] || "0") + decVal[1], settings.precision, true).slice(0, settings.precision);		
						break;                                                                                                     // 387
					                                                                                                            // 388
					default:                                                                                                    // 389
						throw "Moment Duration Format: unable to parse token decimal value.";                                      // 390
				}                                                                                                            // 391
			}                                                                                                             // 392
			                                                                                                              // 393
			// add a negative sign if the value is negative and token is most significant                                 // 394
			if (token.isMost && token.value < 0) {                                                                        // 395
				val = "-" + val;                                                                                             // 396
			}                                                                                                             // 397
                                                                                                                 // 398
			foundFirst = true;                                                                                            // 399
                                                                                                                 // 400
			return val;                                                                                                   // 401
		});                                                                                                            // 402
                                                                                                                 // 403
		// undo the reverse if trimming from the right                                                                 // 404
		if (settings.trim === "right") {                                                                               // 405
			tokens.reverse();                                                                                             // 406
		}                                                                                                              // 407
                                                                                                                 // 408
		return tokens.join("");                                                                                        // 409
	};                                                                                                              // 410
                                                                                                                 // 411
	moment.duration.fn.format.defaults = {                                                                          // 412
		// token definitions                                                                                           // 413
		escape: /\[(.+?)\]/,                                                                                           // 414
		years: /[Yy]+/,                                                                                                // 415
		months: /M+/,                                                                                                  // 416
		weeks: /[Ww]+/,                                                                                                // 417
		days: /[Dd]+/,                                                                                                 // 418
		hours: /[Hh]+/,                                                                                                // 419
		minutes: /m+/,                                                                                                 // 420
		seconds: /s+/,                                                                                                 // 421
		milliseconds: /S+/,                                                                                            // 422
		general: /.+?/,                                                                                                // 423
                                                                                                                 // 424
		// token type names                                                                                            // 425
		// in order of descending magnitude                                                                            // 426
		// can be a space-separated token name list or an array of token names                                         // 427
		types: "escape years months weeks days hours minutes seconds milliseconds general",                            // 428
                                                                                                                 // 429
		// format options                                                                                              // 430
                                                                                                                 // 431
		// trim                                                                                                        // 432
		// "left" - template tokens are trimmed from the left until the first moment token that has a value >= 1       // 433
		// "right" - template tokens are trimmed from the right until the first moment token that has a value >= 1     // 434
		// (the final moment token is not trimmed, regardless of value)                                                // 435
		// `false` - template tokens are not trimmed                                                                   // 436
		trim: "left",                                                                                                  // 437
                                                                                                                 // 438
		// precision                                                                                                   // 439
		// number of decimal digits to include after (to the right of) the decimal point (positive integer)            // 440
		// or the number of digits to truncate to 0 before (to the left of) the decimal point (negative integer)       // 441
		precision: 0,                                                                                                  // 442
                                                                                                                 // 443
		// force first moment token with a value to render at full length even when template is trimmed and first moment token has length of 1
		forceLength: null,                                                                                             // 445
                                                                                                                 // 446
		// template used to format duration                                                                            // 447
		// may be a function or a string                                                                               // 448
		// template functions are executed with the `this` binding of the settings object                              // 449
		// so that template strings may be dynamically generated based on the duration object                          // 450
		// (accessible via `this.duration`)                                                                            // 451
		// or any of the other settings                                                                                // 452
		template: function () {                                                                                        // 453
			var types = this.types,                                                                                       // 454
				dur = this.duration,                                                                                         // 455
				lastType = findLast(types, function (type) {                                                                 // 456
					return dur._data[type];                                                                                     // 457
				});                                                                                                          // 458
                                                                                                                 // 459
			// default template strings for each duration dimension type                                                  // 460
			switch (lastType) {                                                                                           // 461
				case "seconds":                                                                                              // 462
					return "h:mm:ss";                                                                                           // 463
				case "minutes":                                                                                              // 464
					return "d[d] h:mm";                                                                                         // 465
				case "hours":                                                                                                // 466
					return "d[d] h[h]";                                                                                         // 467
				case "days":                                                                                                 // 468
					return "M[m] d[d]";                                                                                         // 469
				case "weeks":                                                                                                // 470
					return "y[y] w[w]";                                                                                         // 471
				case "months":                                                                                               // 472
					return "y[y] M[m]";                                                                                         // 473
				case "years":                                                                                                // 474
					return "y[y]";                                                                                              // 475
				default:                                                                                                     // 476
					return "y[y] M[m] d[d] h:mm:ss";                                                                            // 477
			}                                                                                                             // 478
		}                                                                                                              // 479
	};                                                                                                              // 480
                                                                                                                 // 481
})(this);                                                                                                        // 482
                                                                                                                 // 483
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 512
                                                                                                                       // 513
}).call(this);                                                                                                         // 514
                                                                                                                       // 515
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['oaf:moment-duration-format'] = {};

})();

//# sourceMappingURL=oaf_moment-duration-format.js.map
