/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Date = Package['es5-shim'].Date;
parseInt = Package['es5-shim'].parseInt;
ECMAScript = Package.ecmascript.ECMAScript;
FlowRouter = Package['kadira:flow-router'].FlowRouter;
ReactiveDict = Package['reactive-dict'].ReactiveDict;
SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
MongoObject = Package['aldeed:simple-schema'].MongoObject;
SyncedCron = Package['percolate:synced-cron'].SyncedCron;
Security = Package['ongoworks:security'].Security;
Migrations = Package['percolate:migrations'].Migrations;
process = Package.meteor.process;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
Symbol = Package['ecmascript-runtime'].Symbol;
Map = Package['ecmascript-runtime'].Map;
Set = Package['ecmascript-runtime'].Set;
regeneratorRuntime = Package['ecmascript-runtime'].regeneratorRuntime;
babelHelpers = Package['babel-runtime'].babelHelpers;
Promise = Package.promise.Promise;
Collection2 = Package['aldeed:collection2-core'].Collection2;
moment = Package['momentjs:moment'].moment;
Autoupdate = Package.autoupdate.Autoupdate;

