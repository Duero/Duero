(function () {

/* Imports */
var process = Package.meteor.process;
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteor-base'] = {};

})();

//# sourceMappingURL=meteor-base.js.map
