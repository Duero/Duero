(function () {

/* Imports */
var process = Package.meteor.process;
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorInstall = Package.modules.meteorInstall;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.jquery = {};

})();

//# sourceMappingURL=jquery.js.map
